import torch
import torch.nn as nn
import torch.nn.functional as F
import triton
import triton.language as tl

SEED = 600004
M, D, DT = 1024, 2048, torch.float16

@triton.jit
def relu_kernel(x_ptr, out_ptr, n_elements, BLOCK_SIZE: tl.constexpr):
    pid = tl.program_id(axis=0)
    block_start = pid * BLOCK_SIZE
    offsets = block_start + tl.arange(0, BLOCK_SIZE)
    mask = offsets < n_elements
    x = tl.load(x_ptr + offsets, mask=mask, other=0.0)
    out = tl.maximum(x, 0.0)
    tl.store(out_ptr + offsets, out, mask=mask)

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.ln3_g = nn.Parameter(torch.randn(2048, generator=g).to(dtype), requires_grad=False)
        self.ln3_b = nn.Parameter(torch.randn(2048, generator=g).to(dtype), requires_grad=False)

    def forward(self, x):
        BLOCK_SIZE = 1024
        grid = lambda meta: (triton.cdiv(x.numel(), BLOCK_SIZE),)
        out = torch.empty_like(x, dtype=DT)
        relu_kernel[grid](x, out, x.numel(), BLOCK_SIZE=BLOCK_SIZE)
        out = out * 1.1504
        out = out * 1.2656
        out = F.layer_norm(out, (out.shape[-1],), self.ln3_g, self.ln3_b)
        return out

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

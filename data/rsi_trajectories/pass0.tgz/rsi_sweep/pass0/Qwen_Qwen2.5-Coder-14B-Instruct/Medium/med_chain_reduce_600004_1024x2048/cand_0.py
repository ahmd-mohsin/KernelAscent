import torch
import torch.nn as nn
import torch.nn.functional as F
import triton
import triton.language as tl

SEED = 600004
M, D, DT = 1024, 2048, torch.float16

@triton.autotune(
    configs=[
        triton.Config({'BLOCK_SIZE': 1024}, num_warps=8),
        triton.Config({'BLOCK_SIZE': 512}, num_warps=4),
        triton.Config({'BLOCK_SIZE': 256}, num_warps=2),
    ],
    key=['n_elements']
)
@triton.jit
def fused_relu_and_layer_norm_kernel(x_ptr, out_ptr, ln3_g_ptr, ln3_b_ptr, n_elements, BLOCK_SIZE: tl.constexpr):
    pid = tl.program_id(axis=0)
    block_start = pid * BLOCK_SIZE
    offsets = block_start + tl.arange(0, BLOCK_SIZE)
    mask = offsets < n_elements
    x = tl.load(x_ptr + offsets, mask=mask, other=0.0)
    
    # Apply ReLU
    x = tl.maximum(x, 0.0)
    
    # Scale by constants
    x = x * 1.1504
    x = x * 1.2656
    
    # Load layer norm parameters
    ln3_g = tl.load(ln3_g_ptr + offsets % D, mask=mask, other=0.0)
    ln3_b = tl.load(ln3_b_ptr + offsets % D, mask=mask, other=0.0)
    
    # Compute mean and variance
    mean = tl.sum(x, axis=0) / n_elements
    var = tl.sum((x - mean) ** 2, axis=0) / n_elements
    
    # Normalize and apply layer norm
    epsilon = 1e-6
    normalized = (x - mean) / tl.sqrt(var + epsilon)
    out = normalized * ln3_g + ln3_b
    
    tl.store(out_ptr + offsets, out, mask=mask)

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.ln3_g = nn.Parameter(torch.randn(D, generator=g).to(dtype), requires_grad=False)
        self.ln3_b = nn.Parameter(torch.randn(D, generator=g).to(dtype), requires_grad=False)

    def forward(self, x):
        out = torch.empty_like(x, dtype=DT)
        fused_relu_and_layer_norm_kernel[
            x.numel() // 1024,  # heuristic grid size
            {
                'BLOCK_SIZE': 1024,
            }
        ](x, out, self.ln3_g, self.ln3_b, x.numel())
        return out

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

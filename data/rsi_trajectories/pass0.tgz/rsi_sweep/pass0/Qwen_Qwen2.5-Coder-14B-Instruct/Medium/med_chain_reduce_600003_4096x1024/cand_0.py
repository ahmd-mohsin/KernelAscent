import math
import torch
import torch.nn as nn
import torch.nn.functional as F

SEED = 600003
M, D, DT = 4096, 1024, torch.bfloat16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        self.linear1 = nn.Linear(D, D, dtype=dtype)
        self.linear2 = nn.Linear(D, D, dtype=dtype)
        self.g = torch.Generator().manual_seed(SEED)

    def forward(self, x):
        x = F.gelu(self.linear1(x))
        x = F.gelu(self.linear2(x))
        x = F.softmax(x, dim=-1)
        return x

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

# Ensure reproducibility
torch.manual_seed(SEED)
torch.use_deterministic_algorithms(True)

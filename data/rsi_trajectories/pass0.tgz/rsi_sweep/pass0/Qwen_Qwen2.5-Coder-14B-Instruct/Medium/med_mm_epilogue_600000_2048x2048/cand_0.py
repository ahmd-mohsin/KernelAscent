import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.cuda.amp as amp
import triton
import triton.language as tl
import math

SEED = 600000
M, D, DT = 2048, 2048, torch.bfloat16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.W0 = nn.Parameter((torch.randn(2048, 512, generator=g) / math.sqrt(2048)).to(dtype), requires_grad=False)

    @amp.autocast()
    def forward(self, x):
        x = self.matmul_kernel(x, self.W0)
        x = torch.relu(x)
        return x

    @staticmethod
    @triton.jit(device=True)
    def matmul_kernel(x_ptr, w_ptr, out_ptr, M, N, K, BLOCK_M: tl.constexpr, BLOCK_K: tl.constexpr, BLOCK_N: tl.constexpr):
        pid_m = tl.program_id(0)
        pid_n = tl.program_id(1)

        # Map program IDs to block IDs
        bid_m = pid_m // (BLOCK_M // 16)
        bid_n = pid_n // (BLOCK_N // 16)

        # Compute the row and column indices within the block
        row = bid_m * BLOCK_M + tl.arange(0, BLOCK_M)
        col = bid_n * BLOCK_N + tl.arange(0, BLOCK_N)

        # Load data from global memory to shared memory
        x_block = tl.load(x_ptr + bid_m * M * BLOCK_K + row[:, None] * BLOCK_K + tl.arange(0, BLOCK_K)[None, :])
        w_block = tl.load(w_ptr + tl.arange(0, BLOCK_K)[:, None] * BLOCK_N + col[None, :])

        # Perform the matrix multiplication
        acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)
        for k in range(0, K, BLOCK_K):
            x_block = tl.load(x_ptr + bid_m * M * BLOCK_K + row[:, None] * BLOCK_K + k[None, :])
            w_block = tl.load(w_ptr + k[:, None] * BLOCK_N + col[None, :])
            acc += tl.dot(x_block, w_block)

        # Write the result back to global memory
        tl.store(out_ptr + bid_m * M * BLOCK_N + row[:, None] * BLOCK_N + col[None, :], acc.to(x_ptr.dtype))

    def forward_triton(self, x, w):
        # Define the block size
        BLOCK_M = 128
        BLOCK_N = 128
        BLOCK_K = 128

        # Allocate output tensor
        out = torch.empty((x.size(0), w.size(1)), dtype=torch.float32, device=x.device)

        # Launch the kernel
        grid = lambda META: (
            triton.cdiv(x.size(0), BLOCK_M),
            triton.cdiv(w.size(1), BLOCK_N),
        )
        self.matmul_kernel[x.size(0), w.size(1)](x, w, out, x.size(0), w.size(1), w.size(0), BLOCK_M, BLOCK_K, BLOCK_N)

        return out

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

# Create and compile the model
model = ModelNew()
inputs = get_inputs()

# Run the model to trigger compilation
with torch.no_grad():
    model(*inputs)

# Measure performance
def benchmark(model, inputs, num_iterations=100):
    model.eval()
    with torch.no_grad():
        # Warmup
        for _ in range(5):
            model(*inputs)
        # Benchmark
        torch.cuda.synchronize()
        start_event = torch.cuda.Event(enable_timing=True)
        end_event = torch.cuda.Event(enable_timing=True)
        start_event.record()
        for _ in range(num_iterations):
            model(*inputs)
        end_event.record()
        torch.cuda.synchronize()
        elapsed_time = start_event.elapsed_time(end_event) / num_iterations
        return elapsed_time

eager_time = benchmark(model, inputs)
compiled_time = benchmark(model, inputs)

print(f"Eager time: {eager_time:.2f} ms/iter")
print(f"Compiled time: {compiled_time:.2f} ms/iter")

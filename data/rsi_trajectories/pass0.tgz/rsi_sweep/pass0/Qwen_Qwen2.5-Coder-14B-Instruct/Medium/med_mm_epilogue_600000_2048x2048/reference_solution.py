import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.cuda import amp
import torch.jit as jit
import torch._dynamo as dynamo
import torch.utils._pytree as pytree

SEED = 600000
M, D, DT = 2048, 2048, torch.bfloat16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.W0 = nn.Parameter((torch.randn(2048, 512, generator=g) / math.sqrt(2048)).to(dtype), requires_grad=False)

    @amp.autocast()
    def forward(self, x):
        with torch.cuda.amp.autocast(dtype=torch.float32):
            x = torch.matmul(x, self.W0)
        x = torch.relu(x)
        return x

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

# Custom JIT fusion function
@dynamo.optimize("inductor")
class ModelFused(nn.Module):
    def __init__(self, model):
        super().__init__()
        self.model = model

    def forward(self, x):
        return self.model.forward(x)

# Create and compile the model
model = ModelNew()
fused_model = ModelFused(model)
inputs = get_inputs()

# Run the model to trigger compilation
with torch.no_grad():
    fused_model(*inputs)

# Measure performance
def benchmark(model, inputs, num_iterations=100):
    model.eval()
    with torch.no_grad():
        # Warmup
        for _ in range(5):
            model(*inputs)
        # Benchmark
        torch.cuda.synchronize()
        start_event = torch.cuda.Event(enable_timing=True)
        end_event = torch.cuda.Event(enable_timing=True)
        start_event.record()
        for _ in range(num_iterations):
            model(*inputs)
        end_event.record()
        torch.cuda.synchronize()
        elapsed_time = start_event.elapsed_time(end_event) / num_iterations
        return elapsed_time

eager_time = benchmark(model, inputs)
compiled_time = benchmark(fused_model, inputs)

print(f"Eager time: {eager_time:.2f} ms/iter")
print(f"Compiled time: {compiled_time:.2f} ms/iter")

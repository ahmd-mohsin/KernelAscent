import math
import torch
import torch.nn as nn
import torch.nn.functional as F

SEED = 600001
M, D, DT = 1024, 2048, torch.bfloat16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.W0 = nn.Parameter((torch.randn(D, M, generator=g) / math.sqrt(D)).to(dtype), requires_grad=True)
        self.b1 = nn.Parameter(torch.randn(M, generator=g).to(dtype), requires_grad=True)

    def forward(self, x):
        x = F.linear(x, self.W0, self.b1)
        return x

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

# Example usage
if __name__ == "__main__":
    model = ModelNew()
    inputs = get_inputs()[0]
    outputs = model(inputs)
    print(outputs.shape)

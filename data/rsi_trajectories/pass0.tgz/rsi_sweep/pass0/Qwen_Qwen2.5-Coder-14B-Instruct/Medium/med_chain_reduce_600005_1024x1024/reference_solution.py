import math
import torch
import torch.nn as nn
import torch.nn.functional as F

SEED = 600005
M, D, DT = 1024, 1024, torch.bfloat16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.rms2_w = nn.Parameter(torch.randn(1024, generator=g).to(dtype), requires_grad=False)

    def forward(self, x):
        x = torch.relu(x)
        x = F.gelu(x)
        with torch.cuda.amp.autocast(enabled=True, dtype=torch.float32):
            _xf = x.float()
            rms = torch.rsqrt(_xf.pow(2).mean(-1, keepdim=True) + 1e-6)
            x = (_xf * rms).to(x.dtype) * self.rms2_w
        return x

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

import torch
import torch.nn as nn
import torch.nn.functional as F

SEED = 600005
M, D, DT = 1024, 1024, torch.bfloat16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.rms2_w = nn.Parameter(torch.randn(1024, generator=g).to(dtype), requires_grad=False)

    @torch.jit.script
    def fused_forward(self, x):
        x = torch.relu(x)
        x = F.gelu(x)
        xf = x.float()
        rms = torch.rsqrt(xf.pow(2).mean(-1, keepdim=True) + 1e-6)
        x = (xf * rms).to(x.dtype) * self.rms2_w
        return x

    def forward(self, x):
        return self.fused_forward(x)

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

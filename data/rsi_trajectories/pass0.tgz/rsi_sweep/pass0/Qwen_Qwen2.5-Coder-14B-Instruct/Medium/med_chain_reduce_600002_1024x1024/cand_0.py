import torch
import torch.nn as nn
import torch.nn.functional as F
from triton import cdiv
from triton.language import kernel, LaunchContext, mma, blockIdx, threadIdx, float16, int32, grid
import triton.language as tl

SEED = 600002
M, D, DT = 1024, 1024, torch.float16

@kernel
def relu_kernel(x_ptr, y_ptr, n_elements):
    pid = tl.program_id(axis=0)
    block_start = pid * blockDim.x
    offsets = block_start + tl.arange(0, blockDim.x)
    mask = offsets < n_elements
    x = tl.load(x_ptr + offsets, mask=mask)
    y = tl.where(x > 0, x, 0.0)
    tl.store(y_ptr + offsets, y, mask=mask)

def relu_triton(x):
    y = torch.empty_like(x)
    n_elements = x.numel()
    grid = lambda meta: (cdiv(n_elements, meta['BLOCK_SIZE']),)
    relu_kernel[grid](x.data_ptr(), y.data_ptr(), n_elements, BLOCK_SIZE=1024)
    return y

@kernel
def softmax_kernel(x_ptr, y_ptr, n_elements, max_val):
    pid = tl.program_id(axis=0)
    block_start = pid * blockDim.x
    offsets = block_start + tl.arange(0, blockDim.x)
    mask = offsets < n_elements
    x = tl.load(x_ptr + offsets, mask=mask)
    exp_x = tl.exp(x - max_val)
    sum_exp_x = tl.sum(exp_x, axis=0)
    y = exp_x / sum_exp_x
    tl.store(y_ptr + offsets, y, mask=mask)

def softmax_triton(x):
    max_val = tl.max(x)
    y = torch.empty_like(x)
    n_elements = x.numel()
    grid = lambda meta: (cdiv(n_elements, meta['BLOCK_SIZE']),)
    softmax_kernel[grid](x.data_ptr(), y.data_ptr(), n_elements, max_val, BLOCK_SIZE=1024)
    return y

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.weight = nn.Parameter(torch.randn(D, D, generator=g).to(dtype))
        self.bias = nn.Parameter(torch.randn(D, generator=g).to(dtype))

    def forward(self, x):
        x = torch.matmul(x, self.weight) + self.bias
        x = relu_triton(x)
        x = x * 1.4263
        x = relu_triton(x)
        x = softmax_triton(x)
        return x

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

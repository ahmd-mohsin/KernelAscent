import math
import torch
import torch.nn as nn
import torch.nn.functional as F
import triton
import triton.language as tl

SEED = 700002
M, D, DT = 2048, 1024, torch.bfloat16

@triton.jit
def matmul_relu_softmax_kernel(
    x_ptr, w_ptr, out_ptr, M, N, K,
    BLOCK_M: tl.constexpr, BLOCK_N: tl.constexpr, BLOCK_K: tl.constexpr,
    GROUP_M: tl.constexpr,
    ACTIVATION_RELU: tl.constexpr,
    ACTIVATION_SOFTMAX: tl.constexpr,
    ACCUM_TYPE: tl.constexpr,
    **META
):
    pid = tl.program_id(axis=0)
    grid_m = tl.cdiv(M, BLOCK_M)
    grid_n = tl.cdiv(N, BLOCK_N)
    m_idx = pid // grid_n
    n_idx = pid % grid_n

    # Load x and w
    offsets_m = m_idx * BLOCK_M + tl.arange(0, BLOCK_M)
    offsets_k = n_idx * BLOCK_K + tl.arange(0, BLOCK_K)
    offsets_n = tl.arange(0, BLOCK_N)
    x_ptrs = x_ptr + offsets_m[:, None] * K + offsets_k[None, :]
    w_ptrs = w_ptr + offsets_k[:, None] * N + offsets_n[None, :]
    x = tl.load(x_ptrs, mask=(offsets_m[:, None] < M) & (offsets_k[None, :] < K), other=0.0)
    w = tl.load(w_ptrs, mask=(offsets_k[:, None] < K) & (offsets_n[None, :] < N), other=0.0)

    # Accumulate result
    accumulator = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACCUM_TYPE)
    for _ in range(0, K, BLOCK_K):
        accumulator += tl.dot(x, w)
        offsets_k += BLOCK_K
        x_ptrs += BLOCK_K * K
        w_ptrs += BLOCK_K * N
        x = tl.load(x_ptrs, mask=(offsets_m[:, None] < M) & (offsets_k[None, :] < K), other=0.0)
        w = tl.load(w_ptrs, mask=(offsets_k[:, None] < K) & (offsets_n[None, :] < N), other=0.0)

    if ACTIVATION_RELU:
        accumulator = tl.maximum(accumulator, 0.0)

    # Softmax
    if ACTIVATION_SOFTMAX:
        max_val = tl.max(accumulator, axis=1)
        max_vals = tl.broadcast_to(max_val[:, None], accumulator.shape)
        exp_accumulator = tl.exp(accumulator - max_vals)
        sum_exp_accumulator = tl.sum(exp_accumulator, axis=1)
        sum_exp_accumulators = tl.broadcast_to(sum_exp_accumulator[:, None], accumulator.shape)
        accumulator = exp_accumulator / sum_exp_accumulators

    # Store result
    out_ptrs = out_ptr + offsets_m[:, None] * N + offsets_n[None, :]
    tl.store(out_ptrs, accumulator, mask=(offsets_m[:, None] < M) & (offsets_n[None, :] < N))

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.W0 = nn.Parameter((torch.randn(1024, 4096, generator=g) / math.sqrt(1024)).to(dtype), requires_grad=False)

    def forward(self, x):
        out = torch.empty_like(x)
        BLOCK_M = 128
        BLOCK_N = 128
        BLOCK_K = 64
        GROUP_M = 8
        matmul_relu_softmax_kernel[(x.shape[0] * x.shape[1] + BLOCK_M - 1) // BLOCK_M](
            x_ptr=x.data_ptr(),
            w_ptr=self.W0.data_ptr(),
            out_ptr=out.data_ptr(),
            M=x.shape[0],
            N=self.W0.shape[1],
            K=x.shape[1],
            BLOCK_M=BLOCK_M,
            BLOCK_N=BLOCK_N,
            BLOCK_K=BLOCK_K,
            GROUP_M=GROUP_M,
            ACTIVATION_RELU=True,
            ACTIVATION_SOFTMAX=True,
            ACCUM_TYPE=tl.float32,
            num_warps=4
        )
        out = out * 1.2116
        return out

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

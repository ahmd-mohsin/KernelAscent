import math
import torch
import torch.nn as nn
import torch.nn.functional as F
import triton
import triton.language as tl

SEED = 700000
S, D, DT = 2048, 1024, torch.float16

@triton.jit
def softmax_kernel(output_ptr, input_ptr, n, BLOCK_SIZE: tl.constexpr):
    pid = tl.program_id(axis=0)
    block_start = pid * BLOCK_SIZE
    offsets = block_start + tl.arange(0, BLOCK_SIZE)
    mask = offsets < n
    input = tl.load(input_ptr + offsets, mask=mask, other=-float('inf'))
    max_input = tl.max(input, axis=0)
    input_minus_max = input - max_input
    exp_input = tl.exp(input_minus_max)
    sum_exp_input = tl.sum(exp_input, axis=0)
    softmax_output = exp_input / sum_exp_input
    tl.store(output_ptr + offsets, softmax_output, mask=mask)

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.Wq = nn.Parameter((torch.randn(D, D, generator=g) / math.sqrt(D)).to(dtype), requires_grad=False)
        self.Wk = nn.Parameter((torch.randn(D, D, generator=g) / math.sqrt(D)).to(dtype), requires_grad=False)
        self.Wv = nn.Parameter((torch.randn(D, D, generator=g) / math.sqrt(D)).to(dtype), requires_grad=False)

    def forward(self, x):
        q = x @ self.Wq
        k = x @ self.Wk
        v = x @ self.Wv
        scores = (q @ k.transpose(-1, -2)) / math.sqrt(q.shape[-1])
        
        a = torch.empty_like(scores)
        BLOCK_SIZE = 1024
        grid = lambda meta: (triton.cdiv(scores.shape[1], meta['BLOCK_SIZE']),)
        softmax_kernel[grid](a.data_ptr(), scores.data_ptr(), scores.shape[1], BLOCK_SIZE=BLOCK_SIZE)
        
        return a @ v

# Example usage
if __name__ == "__main__":
    model = ModelNew()
    x = torch.randn(S, D, dtype=torch.float16)
    output = model(x)
    print(output)

import math
import torch
import torch.nn as nn
import torch.nn.functional as F
import triton
import triton.language as tl

SEED = 700001
S, D, DT = 1024, 1024, torch.bfloat16

@triton.jit
def _rope_kernel(Q, rope_cos, rope_sin, stride_qz, stride_qh, stride_qm, stride_qk,
                 BLOCK_M: tl.constexpr, BLOCK_N: tl.constexpr):
    off_m = tl.program_id(0) * BLOCK_M
    off_n = tl.program_id(1) * BLOCK_N
    m_range = off_m + tl.arange(0, BLOCK_M)
    n_range = off_n + tl.arange(0, BLOCK_N)
    m_idx = m_range[:, None]
    n_idx = n_range[None, :]
    cos = rope_cos[m_idx]
    sin = rope_sin[n_idx]
    q = tl.load(Q + m_idx * stride_qz + n_idx * stride_qk, mask=(m_idx < S) & (n_idx < D))
    q1 = q[:, :D//2]
    q2 = q[:, D//2:]
    q_out = tl.zeros_like(q)
    q_out[:, :D//2] = q1 * cos - q2 * sin
    q_out[:, D//2:] = q1 * sin + q2 * cos
    tl.store(Q + m_idx * stride_qz + n_idx * stride_qk, q_out, mask=(m_idx < S) & (n_idx < D))

def _rope(t):
    seq_len, embed_dim = t.shape[-2], t.shape[-1]
    half = embed_dim // 2
    pos = torch.arange(seq_len, device=t.device, dtype=torch.float32).unsqueeze(1)
    freq = torch.exp(torch.arange(0, half, device=t.device, dtype=torch.float32) * (-math.log(10000.0) / max(half, 1)))
    ang = pos * freq
    cos, sin = torch.cos(ang), torch.sin(ang)
    rope_cos = cos.flatten()
    rope_sin = sin.flatten()
    _rope_kernel[t.shape[0], t.shape[1]](
        Q=t,
        rope_cos=rope_cos,
        rope_sin=rope_sin,
        stride_qz=t.stride(0),
        stride_qh=t.stride(1),
        stride_qm=t.stride(2),
        stride_qk=t.stride(3),
        BLOCK_M=128,
        BLOCK_N=128,
        num_warps=4,
    )
    return t

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.Wq = nn.Parameter((torch.randn(D, D, generator=g) / math.sqrt(D)).to(dtype), requires_grad=False)
        self.Wk = nn.Parameter((torch.randn(D, D, generator=g) / math.sqrt(D)).to(dtype), requires_grad=False)
        self.Wv = nn.Parameter((torch.randn(D, D, generator=g) / math.sqrt(D)).to(dtype), requires_grad=False)

    def forward(self, x):
        q = _rope(x @ self.Wq); k = _rope(x @ self.Wk); v = x @ self.Wv
        scores = (q @ k.transpose(-1, -2)) / math.sqrt(q.shape[-1])
        a = torch.softmax(scores, dim=-1)
        return a @ v

class ModelNew:
    def __init__(self):
        self.value = 0

    def increment(self):
        """Increment the value by 1 and return the new value."""
        self.value += 1
        return self.value

    def decrement(self):
        """Decrement the value by 1 and return the new value."""
        self.value -= 1
        return self.value

    def get_value(self):
        """Return the current value."""
        return self.value

# Example usage and test
if __name__ == "__main__":
    model = ModelNew()
    print("Initial value:", model.get_value())  # Should print 0
    print("After increment:", model.increment())  # Should print 1
    print("After increment:", model.increment())  # Should print 2
    print("After decrement:", model.decrement())  # Should print 1
    print("Final value:", model.get_value())  # Should print 1

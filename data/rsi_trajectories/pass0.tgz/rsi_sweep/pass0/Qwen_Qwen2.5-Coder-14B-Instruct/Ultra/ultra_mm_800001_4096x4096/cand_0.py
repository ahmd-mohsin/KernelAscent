import math
import torch
import torch.nn as nn
import torch.nn.functional as F
import triton
import triton.language as tl

SEED = 800001
M, D, DT = 4096, 4096, torch.float16

@triton.jit
def rms_norm_kernel(
    X, W, OUT,
    M: tl.constexpr, N: tl.constexpr,
    BLOCK_M: tl.constexpr, BLOCK_N: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
    EPS: tl.constexpr,
):
    pid = tl.program_id(axis=0)
    num_pid_m = tl.cdiv(M, BLOCK_M)
    num_pid_n = tl.cdiv(N, BLOCK_N)
    num_pid_in_group = GROUP_SIZE_M * num_pid_n
    group_id = pid // num_pid_in_group
    first_pid_m = group_id * GROUP_SIZE_M
    group_size_m = min(GROUP_SIZE_M, num_pid_m - first_pid_m)
    pid_m = first_pid_m + (pid % group_size_m)
    pid_n = (pid % num_pid_in_group) // group_size_m
    offs_m = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
    offs_n = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)
    mask_m = offs_m < M
    mask_n = offs_n < N
    X = X[offs_m[:, None], offs_n]
    W = W[offs_n]
    mean = tl.sum(X * X, axis=1) / N
    rstd = tl.rsqrt(mean + EPS)
    X_normalized = X * rstd[:, None]
    OUT = X_normalized * W[None, :]
    tl.store(OUT, OUT, mask=mask_m[:, None] & mask_n[None, :])

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.W0 = nn.Parameter((torch.randn(4096, 4096, generator=g) / math.sqrt(4096)).to(dtype), requires_grad=False)
        self.b1 = nn.Parameter(torch.randn(4096, generator=g).to(dtype), requires_grad=False)
        self.W2 = nn.Parameter((torch.randn(4096, 1024, generator=g) / math.sqrt(4096)).to(dtype), requires_grad=False)
        self.rms3_w = nn.Parameter(torch.randn(1024, generator=g).to(dtype), requires_grad=False)

    def forward(self, x):
        x = x @ self.W0
        x = x + self.b1
        x = x @ self.W2
        out = torch.empty_like(x)
        grid = lambda META: (triton.cdiv(M, META['BLOCK_M']),)
        rms_norm_kernel[grid](x, self.rms3_w, out, M=M, N=1024, BLOCK_M=128, BLOCK_N=128, GROUP_SIZE_M=8, EPS=1e-6)
        return out

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

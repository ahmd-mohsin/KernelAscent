import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.cuda.amp import autocast

SEED = 800004
S, D, N, E, DT = 512, 1024, 2048, 4, torch.float16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.Wr = nn.Parameter(torch.randn(D, E, generator=g) / math.sqrt(D)).to(dtype)
        self.We = nn.Parameter(torch.randn(E, D, N, generator=g) / math.sqrt(D)).to(dtype)

    @autocast()
    def forward(self, x):
        gate = torch.softmax(x @ self.Wr, dim=-1)
        outs = torch.einsum('se,edn->sdne', gate, self.We)
        y = torch.einsum('sdne,dn->se', outs, x)
        return F.gelu(y)

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(S, D, generator=g).to(DT)]

import torch
import torch.nn as nn
import torch.nn.functional as F
import triton
import triton.language as tl
import math

@triton.jit
def matmul_kernel(
    X, Y, Out,
    X_block_ptr, Y_block_ptr, Out_block_ptr,
    M, N, K,
    BLOCK_M: tl.constexpr, BLOCK_N: tl.constexpr, BLOCK_K: tl.constexpr,
    GROUP_M: tl.constexpr,
    ACTIVATION: tl.constexpr
):
    pid = tl.program_id(axis=0)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # Compute which block to work on
    group_id = pid // (grid_m * GROUP_M)
    group_size = grid_m // GROUP_M
    start_m = group_id * GROUP_M * BLOCK_M + (pid % (grid_m * GROUP_M)) // grid_m * BLOCK_M
    offs_m = start_m + tl.arange(0, BLOCK_M)
    offs_n = tl.arange(0, BLOCK_N)
    offs_k = tl.arange(0, BLOCK_K)

    # Load q, k, v from global memory
    q = tl.load(X_block_ptr + offs_m[:, None] * K + offs_k[None, :])
    k = tl.load(Y_block_ptr + offs_k[:, None] * N + offs_n[None, :])

    # Accumulate result in fp32
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)

    for _ in range(0, K, BLOCK_K):
        acc += tl.dot(q, k)
        q = tl.load(X_block_ptr + (offs_m[:, None] + BLOCK_M) * K + offs_k[None, :], mask=(offs_m[:, None] + BLOCK_M < M))

    # Convert to fp16
    acc = acc.to(tl.float16)

    # Store result to global memory
    if ACTIVATION == 0:
        tl.store(Out_block_ptr + offs_m[:, None] * N + offs_n[None, :], acc)
    elif ACTIVATION == 1:
        tl.store(Out_block_ptr + offs_m[:, None] * N + offs_n[None, :], tl.gelu(acc))

class ModelNew(nn.Module):
    def __init__(self, dtype=torch.bfloat16):
        super().__init__()
        g = torch.Generator().manual_seed(800005)
        self.W0 = nn.Parameter((torch.randn(8192, 4096, generator=g) / math.sqrt(8192)).to(dtype), requires_grad=False)
        self.W2 = nn.Parameter((torch.randn(4096, 4096, generator=g) / math.sqrt(4096)).to(dtype), requires_grad=False)
        self.ln3_g = nn.Parameter(torch.randn(4096, generator=g).to(dtype), requires_grad=False)
        self.ln3_b = nn.Parameter(torch.randn(4096, generator=g).to(dtype), requires_grad=False)

    def forward(self, x):
        x = self.matmul_with_activation(x, self.W0, 0)  # No activation
        x = self.matmul_with_activation(x, self.W2, 1)  # Gelu activation
        x = F.layer_norm(x, (x.shape[-1],), self.ln3_g, self.ln3_b)
        return x

    @staticmethod
    def matmul_with_activation(X, Y, activation):
        BLOCK_M = 128
        BLOCK_N = 256
        BLOCK_K = 32
        GROUP_M = 8

        M, K = X.shape
        _, N = Y.shape

        out = torch.empty((M, N), device=X.device, dtype=X.dtype)

        matmul_kernel[(triton.cdiv(M, BLOCK_M) * triton.cdiv(N, BLOCK_N),)](
            X, Y, out,
            X_block_ptr=triton.block_ptr(X),
            Y_block_ptr=triton.block_ptr(Y),
            Out_block_ptr=triton.block_ptr(out),
            M=M, N=N, K=K,
            BLOCK_M=BLOCK_M, BLOCK_N=BLOCK_N, BLOCK_K=BLOCK_K,
            GROUP_M=GROUP_M,
            ACTIVATION=activation
        )

        return out

def get_inputs():
    g = torch.Generator().manual_seed(800005 + 12345)
    return [torch.randn(4096, 8192, generator=g).to(torch.bfloat16)]

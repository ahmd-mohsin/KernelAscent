import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from triton import jit, kernel
from triton.language import blockIdx, threadIdx, gridDim, blockDim, int32, float16, dot

SEED = 800000
S, D, N, E, DT = 1024, 2048, 2048, 4, torch.float16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.Wr = nn.Parameter((torch.randn(D, E, generator=g) / math.sqrt(D)).to(dtype), requires_grad=False)
        self.We = nn.Parameter((torch.randn(E, D, N, generator=g) / math.sqrt(D)).to(dtype), requires_grad=False)

    @staticmethod
    @jit(device=True)
    def softmax_kernel(out_ptr, in_ptr, S, D, E, stride):
        pid = blockIdx.x * blockDim.x + threadIdx.x
        if pid < S * E:
            row = pid // E
            col = pid % E
            max_val = -float('inf')
            sum_val = 0.0
            for d in range(D):
                val = in_ptr[row * D * E + col * D + d]
                max_val = max(max_val, val)
            for d in range(D):
                val = in_ptr[row * D * E + col * D + d]
                exp_val = math.exp(val - max_val)
                out_ptr[row * E * stride + col] = exp_val
                sum_val += exp_val
            for d in range(D):
                out_ptr[row * E * stride + col] /= sum_val

    def forward(self, x):
        gate = torch.empty((S, E), device=x.device, dtype=DT)
        self.softmax_kernel(gate.data_ptr(), (x @ self.Wr).data_ptr(), S, D, E, gate.stride(1))
        
        outs = torch.empty((E, S, N), device=x.device, dtype=DT)
        for e in range(E):
            outs[e] = x @ self.We[e]
        
        y = torch.zeros_like(x, dtype=DT)
        for s in range(S):
            for e in range(E):
                y[s] += gate[s, e] * outs[e, s]
        
        return F.gelu(y)

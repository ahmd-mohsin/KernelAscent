import math
import torch
import torch.nn as nn
import torch.nn.functional as F

SEED = 500000
M, D, DT = 512, 512, torch.float32

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        pass

    def forward(self, x):
        # Use Fused Softmax from apex if available for better performance
        try:
            from apex import functional as apex_F
            x = apex_F.softmax(x, dim=-1)
        except ImportError:
            x = torch.softmax(x, dim=-1)
        return x

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

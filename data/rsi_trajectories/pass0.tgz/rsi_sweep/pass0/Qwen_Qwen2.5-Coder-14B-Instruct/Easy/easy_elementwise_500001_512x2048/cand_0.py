import torch
import torch.nn as nn
import torch.nn.functional as F
import triton
import triton.language as tl

SEED = 500001
M, D, DT = 512, 2048, torch.float16

@triton.jit
def fused_kernel(x_ptr, b0_ptr, out_ptr, N, M, BLOCK_SIZE_M: tl.constexpr, BLOCK_SIZE_N: tl.constexpr):
    pid_m = tl.program_id(axis=0)
    pid_n = tl.program_id(axis=1)
    
    # Create a mask to avoid out-of-bounds accesses
    rows = tl.arange(0, BLOCK_SIZE_M)
    cols = tl.arange(0, BLOCK_SIZE_N)
    mask = (rows[:, None] < N - pid_m * BLOCK_SIZE_M) & (cols[None, :] < M - pid_n * BLOCK_SIZE_N)
    
    # Load x and b0 into registers
    x = tl.load(x_ptr + pid_m * BLOCK_SIZE_M + rows[:, None] * M + pid_n * BLOCK_SIZE_N + cols[None, :], mask=mask)
    b0 = tl.load(b0_ptr + cols[None, :], mask=cols[None, :] < M - pid_n * BLOCK_SIZE_N)
    
    # Perform the addition and GELU activation
    x = x + b0
    x = 0.5 * x * (1 + tl.math.tanh(0.79788456 * x * (1 + 0.044715 * x * x)))
    
    # Store the result back to global memory
    tl.store(out_ptr + pid_m * BLOCK_SIZE_M + rows[:, None] * M + pid_n * BLOCK_SIZE_N + cols[None, :], x, mask=mask)

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.b0 = nn.Parameter(torch.randn(D, generator=g).to(dtype), requires_grad=False)

    def forward(self, x):
        out = torch.empty_like(x)
        BLOCK_SIZE_M = 64
        BLOCK_SIZE_N = 128
        grid = lambda META: (
            triton.cdiv(x.shape[0], META['BLOCK_SIZE_M']),
            triton.cdiv(x.shape[1], META['BLOCK_SIZE_N'])
        )
        fused_kernel[x.dtype](x, self.b0, out, x.shape[0], x.shape[1], BLOCK_SIZE_M, BLOCK_SIZE_N, grid=grid)
        return out

# Example usage
model = ModelNew()
x = torch.randn(M, D, dtype=torch.float16)
y = model(x)
print(y)

import torch
import torch.nn as nn
import torch.nn.functional as F

SEED = 500001
M, D, DT = 512, 2048, torch.float16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.b0 = nn.Parameter(torch.randn(2048, generator=g).to(dtype), requires_grad=False)

    def forward(self, x):
        x = x + self.b0
        x = F.gelu(x)
        return x

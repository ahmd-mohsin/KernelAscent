import torch
import torch.nn as nn
import torch.nn.functional as F
from triton import jit, device_pointer, cdiv
from triton.language import blockIdx, threadIdx, int32, float32, erf

SEED = 500004
M, D, DT = 1024, 512, torch.float32

@jit(device=True)
def gelu_kernel(
    x_ptr, out_ptr, n_elements,
    BLOCK_SIZE: int32
):
    pid = blockIdx.x * BLOCK_SIZE + threadIdx.x
    if pid < n_elements:
        x_val = float32(x_ptr[pid])
        out_ptr[pid] = x_val * 0.5 * (1.0 + erf(x_val / 1.41421))

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.ln1_g = nn.Parameter(torch.randn(512, generator=g).to(dtype), requires_grad=False)
        self.ln1_b = nn.Parameter(torch.randn(512, generator=g).to(dtype), requires_grad=False)

    def forward(self, x):
        BLOCK_SIZE = 1024
        n_elements = x.numel()
        grid = (cdiv(n_elements, BLOCK_SIZE),)
        block = (BLOCK_SIZE,)
        gelu_kernel[grid, block](
            device_pointer(x.contiguous()),
            device_pointer(x.contiguous()),
            n_elements,
            BLOCK_SIZE=int32(BLOCK_SIZE)
        )
        x = F.layer_norm(x, (x.shape[-1],), self.ln1_g, self.ln1_b)
        return x

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

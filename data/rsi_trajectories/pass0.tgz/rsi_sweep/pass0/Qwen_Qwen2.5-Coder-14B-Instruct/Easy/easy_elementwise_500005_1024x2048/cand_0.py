import torch
import torch.nn as nn
import torch.nn.functional as F
import triton
import triton.language as tl

SEED = 500005
M, D, DT = 1024, 2048, torch.bfloat16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.b0 = nn.Parameter(torch.randn(D, generator=g).to(dtype), requires_grad=False)

    def forward(self, x):
        out = torch.empty_like(x)
        grid = lambda META: (triton.cdiv(M, META['BLOCK_SIZE']), x.shape[0])
        _gelu_kernel[grid](x.contiguous(), self.b0.contiguous(), out, x.shape[0], M, BLOCK_SIZE=1024)
        return out

@triton.jit
def _gelu_kernel(x_ptr, b0_ptr, out_ptr, N, M, BLOCK_SIZE: tl.constexpr):
    pid = tl.program_id(axis=0)
    bid = tl.program_id(axis=1)
    block_start = pid * BLOCK_SIZE
    offsets = block_start + tl.arange(0, BLOCK_SIZE)
    mask = offsets < M
    x = tl.load(x_ptr + bid * M + offsets, mask=mask, other=0.0)
    b0 = tl.load(b0_ptr + offsets, mask=mask, other=0.0)
    x = x + b0
    x = 0.5 * x * (1.0 + tl.math.tanh(0.79788456 * x * (1.0 + 0.044715 * x * x)))
    tl.store(out_ptr + bid * M + offsets, x, mask=mask)

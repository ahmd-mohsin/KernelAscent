import torch
import torch.nn as nn
import torch.nn.functional as F
import triton
import triton.language as tl

SEED = 500003
M, D, DT = 1024, 2048, torch.bfloat16

@triton.jit
def add_kernel(x_ptr, b1_ptr, out_ptr, M: int, D: int, BLOCK_SIZE: tl.constexpr):
    pid = tl.program_id(axis=0)
    bid = tl.program_id(axis=1)
    row = pid * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
    col = bid * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
    mask = (row < M) & (col < D)
    x = tl.load(x_ptr + row[:, None] * D + col[None, :], mask=mask, other=0.0)
    b1 = tl.load(b1_ptr + col, mask=col < D, other=0.0)
    x += b1[None, :]
    x *= 1.0475
    tl.store(out_ptr + row[:, None] * D + col[None, :], x, mask=mask)

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.b1 = nn.Parameter(torch.randn(D, generator=g).to(dtype), requires_grad=False)

    def forward(self, x):
        out = torch.empty_like(x)
        BLOCK_SIZE = 128
        grid = lambda META: (
            triton.cdiv(M, META['BLOCK_SIZE']),
            triton.cdiv(D, META['BLOCK_SIZE']),
        )
        add_kernel[grid](x, self.b1, out, M, D, BLOCK_SIZE)
        return out

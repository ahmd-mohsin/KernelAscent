import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.jit as jit
from torch.utils.cpp_extension import load_inline
import os

SEED = 500002
M, D, DT = 1024, 2048, torch.float16

# Custom CUDA kernel for softmax
softmax_kernel = """
extern "C" __global__ void softmax_forward(
    const half* input, half* output, int N, int C) {
    extern __shared__ half sdata[];
    int tid = threadIdx.x;
    int idx = blockIdx.x * blockDim.x + threadIdx.x;

    if (idx < N * C) {
        int n = idx / C;
        int c = idx % C;
        float max_val = -1e30f;
        for (int i = 0; i < C; ++i) {
            int pos = n * C + i;
            max_val = fmaxf(max_val, static_cast<float>(input[pos]));
        }
        float sum = 0.0f;
        for (int i = 0; i < C; ++i) {
            int pos = n * C + i;
            float val = expf(static_cast<float>(input[pos]) - max_val);
            sdata[tid + i] = static_cast<half>(val);
            sum += val;
        }
        __syncthreads();

        for (int i = 0; i < C; ++i) {
            int pos = n * C + i;
            output[pos] = static_cast<half>(sdata[tid + i] / sum);
        }
    }
}
"""

# Load the custom CUDA kernel
softmax_module = load_inline(name="softmax_module", sources=[softmax_kernel], verbose=True)

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        self.dtype = dtype
        g = torch.Generator().manual_seed(SEED)
        pass

    @jit.script_method
    def forward(self, x):
        x = x.to(self.dtype)
        N, C = x.size()
        output = torch.empty_like(x, dtype=self.dtype)
        block_size = 128
        grid_size = (N * C + block_size - 1) // block_size
        softmax_module.softmax_forward[grid_size, block_size](x.contiguous(), output, N, C)
        return output

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

# Example usage
if __name__ == "__main__":
    model = ModelNew().cuda()
    inputs = get_inputs()[0].cuda()
    outputs = model(inputs)
    print(outputs)

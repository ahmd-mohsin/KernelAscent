import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.cuda.amp import autocast
import math

SEED = 42

class ModelNew(nn.Module):
    def __init__(self, dtype=torch.bfloat16):
        super(ModelNew, self).__init__()
        g = torch.Generator().manual_seed(SEED)
        # Initialize weights with normal distribution
        self.W0 = nn.Parameter(torch.randn(2048, 1024, generator=g) * math.sqrt(2048)).to(dtype)
        self.b1 = nn.Parameter(torch.randn(1024, generator=g)).to(dtype)

    def forward(self, x):
        with autocast(dtype=dtype):
            x = torch.matmul(x, self.W0)
            x = x + self.b1
        return x

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(10, 1024, generator=g).to(torch.bfloat16)]

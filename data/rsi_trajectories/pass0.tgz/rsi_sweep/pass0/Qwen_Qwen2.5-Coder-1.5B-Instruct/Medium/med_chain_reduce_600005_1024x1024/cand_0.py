import torch
import torch.nn as nn
import torch.nn.functional as F
from triton import custom_ops
from triton.ops import aten_max, aten_add

SEED = 600005
M, D, DT = 1024, 1024, torch.bfloat16

@custom_ops(max_dim=-1, axis=1, keepdim=True)
def max_dim_func(x):
    return aten_max(x, dim=max_dim, keepdim=True)

@custom_ops(axis=1, keepdim=True)
def add_axis_func(x):
    return aten_add(x.unsqueeze(-1), axis=axis, keepdim=True)

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        self.rms2_w = nn.Parameter(max_dim_func(torch.zeros(1024, dtype=dtype)), requires_grad=False)

    def forward(self, x):
        x = torch.relu(x)
        x = F.gelu(x)
        _xf = x.float(); x = add_axis_func((_xf.pow(2).sum(-1, keepdim=True) + 1e-6).unsqueeze(-1)).to(x.dtype) * self.rms2_w
        return x

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

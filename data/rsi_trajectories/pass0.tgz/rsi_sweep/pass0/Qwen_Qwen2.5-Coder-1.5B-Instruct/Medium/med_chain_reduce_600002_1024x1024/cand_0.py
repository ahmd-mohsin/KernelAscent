import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.cuda import stream
from triton.inference import TensorLayout, TensorShape, InferenceSession

# Define the model architecture
class ModelNew(nn.Module):
    def __init__(self, dtype=torch.float16):
        super().__init__()
        self.dtype = dtype
        self.tl_model = self._build_tl_model()

    def _build_tl_model(self):
        @triton.jit
        def tl_forward(x, y, z, w, out):
            # Triton ops
            x = F.relu(x)
            x = x * 1.4263
            x = F.relu(x)
            x = F.softmax(x, dim=-1)
            out[...], _ = x, 0  # Assigning softmax output and zero gradient

        # Layouts
        x_layout = TensorLayout(TensorShape((M, D)), dtype=self.dtype)
        y_layout = TensorLayout(TensorShape((M, D)), dtype=self.dtype)
        z_layout = TensorLayout(TensorShape((M, D)), dtype=self.dtype)
        w_layout = TensorLayout(TensorShape((M, D)), dtype=self.dtype)
        out_layout = TensorLayout(TensorShape((M, D)), dtype=self.dtype)

        # Build inference session
        session = InferenceSession(tl_forward, [x_layout, y_layout, z_layout, w_layout, out_layout])

        return session

    def forward(self, x):
        # Run inference
        input_shapes = [(M, D)]
        output_shapes = [(M, D)]
        inputs = []
        outputs = []

        with torch.no_grad():
            for shape in input_shapes:
                input_tensor = torch.randn(shape, device='cuda', dtype=self.dtype)
                inputs.append(input_tensor)
            for shape in output_shapes:
                output_tensor = torch.empty(shape, device='cuda', dtype=self.dtype)
                outputs.append(output_tensor)

        session.run(inputs=inputs, outputs=outputs)

        return outputs[0]

# Example usage
model = ModelNew()
inputs = get_inputs()
output = model(*inputs)
print(output)

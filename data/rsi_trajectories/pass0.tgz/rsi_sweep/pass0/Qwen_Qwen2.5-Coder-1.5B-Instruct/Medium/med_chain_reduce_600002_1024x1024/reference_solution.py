import torch
import torch.nn as nn
import torch.nn.functional as F

SEED = 600002
M, D, DT = 1024, 1024, torch.float16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)

    def forward(self, x):
        # Triton or fused PyTorch ops
        x = torch.relu(x)
        x = x * 1.4263
        x = torch.relu(x)
        x = torch.softmax(x, dim=-1)
        return x

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

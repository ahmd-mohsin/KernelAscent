import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.cuda.amp import autocast

class ModelNew(nn.Module):
    def __init__(self, dtype=dt):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.linear1 = nn.Linear(D, M, bias=False, dtype=dtype)
        self.linear2 = nn.Linear(M, M, bias=False, dtype=dtype)

    def forward(self, x):
        with autocast(dtype=dtype):
            # Concatenate the outputs from both linear layers
            x = torch.cat((self.linear1(x), self.linear2(x)), dim=-1)
            x = F.gelu(x, dtype=dtype)  # Apply gelu activation function with the same dtype
            x = torch.softmax(x, dim=-1, dtype=dtype)  # Apply softmax with the same dtype
        return x

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g)]

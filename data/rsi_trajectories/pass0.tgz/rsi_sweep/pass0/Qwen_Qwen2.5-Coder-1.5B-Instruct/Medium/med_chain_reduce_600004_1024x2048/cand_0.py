import torch
import torch.nn as nn
import torch.nn.functional as F
import timm.models.vision_transformer as vit
from timm.models.layers import LayerNorm
from timm.models.layers.conv2d_same_padding import Conv2dSamePadding
import torch.cuda.amp as autocast
from torch.utils.tensorboard import SummaryWriter

SEED = 600004
M, D, DT = 1024, 2048, torch.float16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.ln3_g = nn.Parameter(torch.randn(2048, generator=g).to(dtype), requires_grad=True)
        self.ln3_b = nn.Parameter(torch.randn(2048, generator=g).to(dtype), requires_grad=True)

    @autocast()
    def forward(self, x):
        with autocast(enabled=True):
            x = torch.relu(x)
            x = x * 1.1504
            x = x * 1.2656
            x = F.layer_norm(x, (x.shape[-1],), self.ln3_g, self.ln3_b)
            return x

# Define a small ViT model for demonstration purposes
class ViTModel(nn.Module):
    def __init__(self, patch_size=16, num_classes=1000):
        super(ViTModel, self).__init__()
        self.patch_size = patch_size
        self.num_classes = num_classes
        self.vit = vit.create_vit('small', in_channels=3, out_indices=[-1])

    def forward(self, x):
        x = self.vit(x)
        x = x.mean(dim=(2, 3))
        return x

# Example usage
if __name__ == "__main__":
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = ModelNew().to(device)
    inputs = get_inputs()[0].to(device)
    outputs = model(inputs)
    print(outputs.shape)  # Should output shape (batch_size, num_classes)

import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.cuda.amp import autocast
from timm.utils.tilable import TileableConv2d

SEED = 600000
M, D, DT = 2048, 2048, torch.bfloat16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.W0 = nn.Parameter((torch.randn(2048, 512, generator=g) / math.sqrt(2048)).to(dtype), requires_grad=False)

    def forward(self, x):
        # Fuse operations into a single kernel
        x = x @ self.W0
        x = F.relu(x)
        
        # Tile the input tensor
        batch_size, channels, height, width = x.shape
        block_height = 64
        block_width = 64
        
        # Create a tiled view of the input
        tiled_x = x.view(batch_size, channels * block_height, block_width, height, width)
        
        # Apply convolution with fused operations
        conv = nn.Conv2d(channels * block_height * block_width, channels, kernel_size=1, stride=1, padding=0, groups=channels, bias=True, dtype=dtype)
        tiled_x = conv(tiled_x)
        
        # Reshape the output back to the original shape
        tiled_x = tiled_x.view(batch_size, channels, height, width)
        
        # Apply ReLU activation
        x = F.relu(tiled_x)
        
        return x

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

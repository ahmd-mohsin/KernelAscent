import torch
import torch.nn as nn
import torch.nn.functional as F
from triton import jit, tensor
from triton.compile import compile_model

SEED = 800004
S, D, N, E, DT = 512, 1024, 2048, 4, torch.float16

@jit
def model_forward(x: tensor(S, D, E), Wr: tensor(E, D), We: tensor(E, D, N)):
    # Compute gate using softmax
    gate = F.softmax(x @ Wr, dim=-1)
    
    # Compute outputs using matrix multiplication and summation
    outs = torch.stack([x @ We[e] for e in range(E)], dim=0)
    y = (gate.transpose(0, 1).unsqueeze(-1) * outs).sum(0)
    
    return y

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.Wr = nn.Parameter((torch.randn(D, E, generator=g) / math.sqrt(D)).to(dtype))
        self.We = nn.Parameter((torch.randn(E, D, N, generator=g) / math.sqrt(D)).to(dtype))

    def forward(self, x):
        # Prepare inputs for Triton
        input_tensor = tensor(x.cpu(), layout=TensorLayouts(format='NCD'))
        wr_tensor = tensor(self.Wr.cpu(), layout=TensorLayouts(format='NDE'))
        we_tensor = tensor(self.We.cpu(), layout=TensorLayouts(format='NED'))

        # Compile the Triton function
        model_func = compile_model(model_forward, "model_forward", inputs=[input_tensor], outputs=[output_tensor])

        # Execute the Triton compiled function
        result = model_func(input_tensor)

        # Move the result back to CPU before returning
        return result.cpu()

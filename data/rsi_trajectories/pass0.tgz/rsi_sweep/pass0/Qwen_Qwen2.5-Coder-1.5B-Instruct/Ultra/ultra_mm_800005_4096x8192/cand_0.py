import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.cuda.amp import autocast
import time

SEED = 800005
M, D, DT = 4096, 8192, torch.bfloat16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.W0 = nn.Parameter((torch.randn(8192, 4096, generator=g) / math.sqrt(8192)).to(dtype), requires_grad=False)
        self.W2 = nn.Parameter((torch.randn(4096, 4096, generator=g) / math.sqrt(4096)).to(dtype), requires_grad=False)
        self.ln3_g = nn.Parameter(torch.randn(4096, generator=g).to(dtype), requires_grad=False)
        self.ln3_b = nn.Parameter(torch.randn(4096, generator=g).to(dtype), requires_grad=False)

    def forward(self, x):
        # Tile the input data
        batch_size, seq_len, _ = x.shape
        tiled_x = x.view(batch_size, 4, seq_len // 4, 4, 4).permute(0, 2, 4, 3, 1)

        # Fuse the operations into one kernel
        with autocast():
            tiled_x = tiled_x.matmul(self.W0)
            tiled_x = F.gelu(tiled_x)
            tiled_x = tiled_x.matmul(self.W2)
            normalized_x = F.layer_norm(tiled_x, (tiled_x.shape[-1],), self.ln3_g, self.ln3_b)

        # Rearrange the tiles back to the original shape
        rearranged_tiled_x = normalized_x.permute(0, 2, 3, 4, 1).view(batch_size, seq_len, -1)

        return rearranged_tiled_x

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

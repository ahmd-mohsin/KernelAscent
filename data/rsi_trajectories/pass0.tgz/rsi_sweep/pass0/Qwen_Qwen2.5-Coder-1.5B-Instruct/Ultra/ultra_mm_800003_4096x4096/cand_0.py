import torch
import torch.nn as nn
import torch.nn.functional as F
from triton import jit, softmax

SEED = 800003
M, D, DT = 4096, 4096, torch.float16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.W0 = nn.Parameter((torch.randn(4096, 4096, generator=g) / math.sqrt(4096)).to(dtype), requires_grad=False)
        self.W2 = nn.Parameter((torch.randn(4096, 512, generator=g) / math.sqrt(4096)).to(dtype), requires_grad=False)
        self.ln3_g = nn.Parameter(torch.randn(512, generator=g).to(dtype), requires_grad=False)
        self.ln3_b = nn.Parameter(torch.randn(512, generator=g).to(dtype), requires_grad=False)

    @jit
    def forward(self, x):
        # Apply linear transformation
        x = x @ self.W0
        
        # Apply ReLU activation
        x = F.relu(x)
        
        # Apply layer normalization
        x = F.layer_norm(x, (x.shape[-1],), self.ln3_g, self.ln3_b)
        
        # Apply second linear transformation
        x = x @ self.W2
        
        return x

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.cuda.amp import autocast
import timm
from timm.models.layers import create_custom_kernel

# Define a custom kernel for the operation
@create_custom_kernel(name='custom_op', code=f"""
__global__ void custom_op(float* input, float* output, int M, int D, int N) {{
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < M * D * N) {{
        int i = idx % D; // Assuming N=1
        int j = idx / D; // Assuming N=1
        int k = idx / (D * M); // Assuming N=1
        output[idx] = input[i * D * M + j * M + k];
    }}
}}
""")
class ModelNew(nn.Module):
    def __init__(self, dtype=dt):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.W0 = nn.Parameter((torch.randn(4096, 4096, generator=g) / math.sqrt(4096)).to(dtype), requires_grad=False)
        self.b1 = nn.Parameter(torch.randn(4096, generator=g).to(dtype), requires_grad=False)
        self.W2 = nn.Parameter((torch.randn(4096, 1024, generator=g) / math.sqrt(4096)).to(dtype), requires_grad=False)
        self.rms3_w = nn.Parameter(torch.randn(1024, generator=g).to(dtype), requires_grad=False)

    @autocast()
    def forward(self, x):
        # Tile the input tensor and reshape it to match the custom kernel dimensions
        B, M, D, N = x.shape
        tiled_x = x.permute(0, 3, 2, 1).reshape(B, M * D, N, 1).contiguous()  # Ensure contiguous memory to avoid memory errors
        
        # Apply custom kernel
        output = torch.empty_like(tiled_x)
        custom_op[tiled_x.device].forward(
            tiled_x.data_ptr(),
            output.data_ptr(),
            B,
            M * D,
            N
        )
        
        # Unroll the tiled output
        unrolled_output = output.view(B, M, D, N)
        
        # Apply the remaining operations
        unrolled_output = unrolled_output @ self.W0
        unrolled_output = unrolled_output + self.b1
        unrolled_output = unrolled_output @ self.W2
        _xf = unrolled_output.float(); unrolled_output = (_xf * torch.rsqrt(_xf.pow(2).mean(-1, keepdim=True) + 1e-6)).to(unrolled_output.dtype) * self.rms3_w
        
        return unrolled_output

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

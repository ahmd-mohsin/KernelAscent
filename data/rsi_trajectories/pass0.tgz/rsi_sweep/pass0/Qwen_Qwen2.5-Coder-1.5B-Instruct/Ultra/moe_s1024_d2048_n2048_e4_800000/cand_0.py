import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from triton import jit

# Define a custom Triton kernel for efficient matrix multiplication
@jit
def matmul_triton(A, B, C):
    batch_size, rows_A, cols_A = A.shape
    rows_B, cols_B, depth_B = B.shape
    batch_size, rows_C, cols_C = C.shape
    
    if cols_B != depth_B:
        raise ValueError("Matrix dimensions do not match for multiplication.")
    
    for b in range(batch_size):
        for i in range(rows_C):
            for j in range(cols_C):
                c_ij = 0.0
                for k in range(cols_A):
                    c_ij += A[b, i, k] * B[b, k, j]
                C[b, i, j] = c_ij

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.Wr = nn.Parameter((torch.randn(D, E, generator=g) / math.sqrt(D)).to(dtype), requires_grad=False)
        self.We = nn.Parameter((torch.randn(E, D, N, generator=g) / math.sqrt(D)).to(dtype), requires_grad=False)

    def forward(self, x):
        # Reshape x to allow broadcasting with We
        x_reshaped = x.view(-1, D)
        
        # Calculate the output using the reshaped x
        outs = []
        for e in range(E):
            out = torch.matmul(x_reshaped, self.We[e])
            outs.append(out)
        
        y = (torch.cat(outs, dim=-1).view(batch_size, -1, N)).sum(2)
        return F.gelu(y)

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(S, D, generator=g).to(DT)]

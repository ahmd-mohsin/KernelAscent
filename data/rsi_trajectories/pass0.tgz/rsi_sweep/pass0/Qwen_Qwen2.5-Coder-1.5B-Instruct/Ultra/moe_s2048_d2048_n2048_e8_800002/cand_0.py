import torch
import torch.nn as nn
import torch.nn.functional as F
import math

SEED = 800002
S, D, N, E, DT = 2048, 2048, 2048, 8, torch.float16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.Wr = nn.Parameter(torch.randn(D, E, generator=g) / math.sqrt(D)).to(dtype), requires_grad=False)
        self.We = nn.Parameter(torch.randn(E, D, N, generator=g) / math.sqrt(E)).to(dtype), requires_grad=False)

    def forward(self, x):
        # Triton op: softmax along the last dimension
        gate = torch.softmax(x, dim=-2)
        
        # Fused PyTorch op: bmm and sum along the first dimension
        outs = torch.bmm(x.unsqueeze(-2), self.We).squeeze(-2)
        
        # Fused PyTorch op: gelu along the first dimension
        y = F.gelu(outs)
        
        return y

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(S, D, generator=g).to(DT)]

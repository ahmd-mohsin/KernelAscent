import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.cuda.amp import autocast

class ModelNew(nn.Module):
    def __init__(self, dtype=torch.float32, seed=SEED):
        super().__init__()
        g = torch.Generator().manual_seed(seed)
        self.Wq = nn.Parameter(torch.randn(D, D, generator=g) / math.sqrt(D), requires_grad=False)
        self.Wk = nn.Parameter(torch.randn(D, D, generator=g) / math.sqrt(D), requires_grad=False)
        self.Wv = nn.Parameter(torch.randn(D, D, generator=g) / math.sqrt(D), requires_grad=False)

    @autocast()
    def forward(self, x):
        # Fuse matrix multiplications into a single operation
        qk_v = torch.matmul(x, self.Wq) * torch.matmul(self.Wk, self.Wv) * torch.matmul(self.Wv, x)
        
        # Compute softmax along the last dimension
        scores = F.softmax(qk_v / math.sqrt(qk_v.shape[-1]), dim=-1)
        
        # Compute attention weights
        a = scores
        
        # Return attention weights
        return a

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch

SEED = 700004
S, D, DT = 512, 512, torch.bfloat16

def _rope(t):
    S, E = t.shape
    half = E // 2
    pos = torch.arange(S, device=t.device, dtype=torch.float32).unsqueeze(1)
    freq = torch.exp(torch.arange(0, half, device=t.device, dtype=torch.float32) * (-torch.log(torch.tensor(10000.0, device=t.device)) / max(half, 1)))
    ang = pos * freq
    cos, sin = torch.cos(ang), torch.sin(ang)
    t1 = t[..., :half].float(); t2 = t[..., half:half * 2].float()
    out = t.float().clone()
    out[..., :half] = t1 * cos - t2 * sin
    out[..., half:half * 2] = t1 * sin + t2 * cos
    return out.to(t.dtype)

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.Wq = nn.Parameter((torch.randn(D, D, generator=g) / math.sqrt(D)).to(dtype), requires_grad=False)
        self.Wk = nn.Parameter((torch.randn(D, D, generator=g) / math.sqrt(D)).to(dtype), requires_grad=False)
        self.Wv = nn.Parameter((torch.randn(D, D, generator=g) / math.sqrt(D)).to(dtype), requires_grad=False)

    def forward(self, x):
        # Tile the input tensor
        batch_size, seq_len, embed_dim = x.shape
        n_tiles = 8  # Adjust based on A100's memory capacity
        x_tile = x.view(batch_size, seq_len // n_tiles, n_tiles, embed_dim)

        # Compute query, key, value
        q_tile = _rope(x_tile @ self.Wq)
        k_tile = _rope(x_tile @ self.Wk)
        v_tile = x_tile @ self.Wv

        # Perform dot product and softmax
        scores_tile = (q_tile @ k_tile.transpose(-1, -2)) / math.sqrt(q_tile.shape[-1])
        scores_tile += 1e-9  # Add a small epsilon to avoid division by zero

        # Softmax along the last dimension
        a_tile = torch.softmax(scores_tile, dim=-1)

        # Multiply by value tiles
        output_tile = a_tile @ v_tile

        # Concatenate the results
        output = output_tile.view(batch_size, seq_len, embed_dim)

        return output

# Example usage
model = ModelNew()
input_tensor = torch.randn(1, 1024, 512, dtype=DT)
output = model(input_tensor)
print(output.shape)

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.cuda.amp as amp
import timm
from timm.models.layers import PatchEmbed, MlpBlock

SEED = 700005
M, D, DT = 1024, 4097, torch.float16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        self.patch_embed = PatchEmbed(
            in_channels=D,
            patch_size=M,
            embed_dim=M * 8,
            dropout=0.0,
            bias=True,
            use_checkpoint=True,
        )
        self.mlp_blocks = nn.Sequential(
            *[MlpBlock(
                hidden_features=M * 8,
                out_features=M * 8,
                drop_rate=0.0,
                act_layer=F.gelu,
                drop_path=0.0,
            ) for _ in range(3)],
        )

    def forward(self, x):
        x = self.patch_embed(x)
        x = self.mlp_blocks(x)
        # Apply softmax after mlp blocks
        x = F.softmax(x, dim=-1)
        # Take mean along spatial dimensions
        x = x.mean(dim=(1, 2))
        return x

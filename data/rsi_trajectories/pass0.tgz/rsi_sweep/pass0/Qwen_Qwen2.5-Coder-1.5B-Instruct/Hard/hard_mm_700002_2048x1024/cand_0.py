import torch
import torch.nn as nn
import torch.nn.functional as F
from timm.models.layers import create_mlp

# Set the random seed
SEED = 700002
M, D, DT = 2048, 1024, torch.bfloat16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.linear = nn.Linear(4096, M, bias=False, device='cuda') if torch.cuda.is_available() else nn.Linear(4096, M, bias=False)
        self.relu = nn.ReLU()

    def forward(self, x):
        # Use nn.Linear for the transformation
        x = self.linear(x)
        x = self.relu(x)
        x = x * 1.2116
        x = F.softmax(x, dim=-1)
        return x

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

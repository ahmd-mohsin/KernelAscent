import math
import torch
import torch.nn as nn
import torch.nn.functional as F

SEED = 700001
S, D, DT = 1024, 1024, torch.bfloat16

def _rope_new(x, d_model, dtype=torch.bfloat16):
    """Positional Encoding Function"""
    seq_len = x.size(0)
    div_term = torch.exp(torch.arange(0, d_model, 2.0) * (-math.log(d_model) / d_model)).to(dtype)
    pos = torch.arange(seq_len).unsqueeze(-1).to(dtype)
    pos *= div_term.unsqueeze(0)
    return torch.cat((pos.sin(), pos.cos()), axis=-1)

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.Wq = nn.Parameter(torch.randn(D, D, generator=g) / math.sqrt(D)).to(dtype), requires_grad=False)
        self.Wk = nn.Parameter(torch.randn(D, D, generator=g) / math.sqrt(D)).to(dtype), requires_grad=False)
        self.Wv = nn.Parameter(torch.randn(D, D, generator=g) / math.sqrt(D)).to(dtype), requires_grad=False)

    def forward(self, x):
        q = _rope_new(x, D, dtype)
        k = _rope_new(x, D, dtype)
        v = x @ self.Wv
        scores = (q @ k.transpose(-1, -2))
        # Apply softmax over the last dimension to normalize attention weights
        a = torch.softmax(scores, dim=-2)
        # Multiply attention weights with values and sum them up
        output = a @ v
        return output

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(S, D, generator=g).to(DT)]

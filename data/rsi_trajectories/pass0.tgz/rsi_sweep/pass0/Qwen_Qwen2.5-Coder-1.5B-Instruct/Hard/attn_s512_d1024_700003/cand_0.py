import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.cuda.amp import autocast
import triton
import triton.language as tl
import triton.ops

SEED = 700003
S, D, DT = 512, 1024, torch.bfloat16

@triton.jit
def matmul(A, B, C, M, N, K, BLOCK_SIZE=128):
    # Assuming A and B are of shape (M, K), (K, N)
    M, K, N = A.shape[0], A.shape[1], B.shape[1]
    stride_A = K * BLOCK_SIZE
    stride_B = N * BLOCK_SIZE
    stride_C = M * N

    for i in range(M // BLOCK_SIZE):
        for j in range(K // BLOCK_SIZE):
            for k in range(N // BLOCK_SIZE):
                acc = tl.zeros_like(C[i*BLOCK_SIZE:(i+1)*BLOCK_SIZE, j*BLOCK_SIZE:(j+1)*BLOCK_SIZE])
                for l in range(BLOCK_SIZE):
                    acc += A[i*BLOCK_SIZE+i+l, j*BLOCK_SIZE:j+l] * B[l*BLOCK_SIZE:k*l+k, j*BLOCK_SIZE:j+l]
                C[i*BLOCK_SIZE:i+1*BLOCK_SIZE, j*BLOCK_SIZE:j+1*BLOCK_SIZE] = acc

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.Wq = nn.Parameter((torch.randn(D, D, generator=g) / math.sqrt(D)).to(dtype), requires_grad=False)
        self.Wk = nn.Parameter((torch.randn(D, D, generator=g) / math.sqrt(D)).to(dtype), requires_grad=False)
        self.Wv = nn.Parameter((torch.randn(D, D, generator=g) / math.sqrt(D)).to(dtype), requires_grad=False)

    def forward(self, x):
        with autocast(enabled=True):
            q = x @ self.Wq
            k = x @ self.Wk
            v = x @ self.Wv
            scores = (q @ k.transpose(-1, -2)) / math.sqrt(q.shape[-1])

            # Reshape and transpose scores for softmax computation
            scores_reshaped = scores.view(M, K, N)
            scores_transposed = scores_reshaped.permute(0, 2, 1)

            # Flatten softmax scores before applying matrix multiplication
            softmax_scores_flattened = scores_transposed.view(M*N, K*N)

            # Compute softmax using Triton
            softmax_scores = triton.ops.softmax(softmax_scores_flattened)

            # Perform matrix multiplication using Triton
            softmax_scores_reshaped = softmax_scores.view(M, N, K)
            C = triton.ops.matmul(softmax_scores_reshaped, v, strides=[M*K, K*D, D*K])

            return C


import math
import torch
import torch.nn as nn
import torch.nn.functional as F

from triton import custom_ops, jit

SEED = 500005
M, D, DT = 1024, 2048, torch.bfloat16

# Corrected gelu_unfolded function
@custom_ops(Tensor, int)
def gelu_unfolded(input, kernel_size):
    """
    This function applies a GELU (Gaussian Error Linear Unit) activation function
    to each element of the input tensor using a specified kernel size.
    
    Parameters:
    - input: Input tensor with shape (batch_size, sequence_length, hidden_size).
    - kernel_size: Size of the convolutional kernel used for the GELU activation.
    
    Returns:
    - Output tensor with shape (batch_size, sequence_length, hidden_size) containing the GELU activations.
    """
    # Unfold the input tensor into multiple segments
    unfolded_input = input.unfold(1, kernel_size, kernel_size)
    
    # Compute the mean and standard deviation along the sequence dimension
    mean = unfolded_input.mean(dim=-1, keepdim=True)
    std = unfolded_input.std(dim=-1, keepdim=True)
    
    # Apply the ReLU formula
    relu_term = torch.relu(unfolded_input - mean)
    
    # Apply the GELU formula using ReLU instead of exp
    gelu_output = mean + std * relu_term
    
    return gelu_output

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.b0 = nn.Parameter(torch.randn(2048, generator=g).to(dtype), requires_grad=False)

    @jit
    def forward(self, x):
        x = x + self.b0
        x = gelu_unfolded(x, kernel_size=3)
        x = torch.relu(x)
        return x

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

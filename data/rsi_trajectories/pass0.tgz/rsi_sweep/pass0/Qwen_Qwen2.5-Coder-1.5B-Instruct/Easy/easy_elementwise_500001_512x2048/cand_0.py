import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.cuda.amp import autocast

class ModelNew(nn.Module):
    def __init__(self, dtype=torch.float32):
        super().__init__()
        # Set the random seed for reproducibility
        torch.manual_seed(SEED)
        
        # Initialize b0 with a uniform distribution
        self.b0 = nn.Parameter(torch.rand(2048).to(dtype=dtype), requires_grad=True)

    @autocast()
    def forward(self, x):
        x = x + self.b0
        x = F.gelu(x)
        return x

import torch
import torch.nn as nn
import torch.nn.functional as F
from triton import cuda

SEED = 500004
M, D, DT = 1024, 512, torch.float32

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.ln1_g = nn.Parameter(torch.randn(512, generator=g).to(dtype))
        self.ln1_b = nn.Parameter(torch.randn(512, generator=g).to(dtype))

    @cuda.jit
    def gelu_kernel(self, x: torch.Tensor) -> torch.Tensor:
        # Gelu operation using CUDA kernel
        gelu_kernel = """
            extern "C" __global__ void gelu_kernel(float* x, float* out, int n) {
                int idx = blockIdx.x * blockDim.x + threadIdx.x;
                if (idx < n) {
                    out[idx] = x[idx] * (1 + tanh((x[idx] / sqrt(2)) * (1 - exp(-pow((x[idx] / sqrt(2)), 2)))));
                }
            }
        """

        # Load CUDA kernels
        cuda.load(gelu_kernel)

        # Apply gelu operation
        gelu_output = torch.empty_like(x)
        gelu_kernel.grid=(math.ceil(x.size(0) / 64), 1), block=(64, 1), args=(x.data_ptr(), gelu_output.data_ptr(), x.size(0)))

        return gelu_output

    @cuda.jit
    def layer_norm_kernel(self, x: torch.Tensor, mean: torch.Tensor, var: torch.Tensor, gamma: torch.Tensor, beta: torch.Tensor, n: int, eps: float) -> torch.Tensor:
        # Layer norm operation using CUDA kernel
        layer_norm_kernel = """
            extern "C" __global__ void layer_norm_kernel(float* x, float* mean, float* var, float* gamma, float* beta, int n, float eps) {
                int idx = blockIdx.x * blockDim.x + threadIdx.x;
                if (idx < n) {
                    float mean_val = mean[idx];
                    float var_val = var[idx];
                    float x_val = x[idx];
                    float scale = gamma[idx];
                    float bias = beta[idx];

                    float x_scaled = x_val * scale;
                    float variance = x_scaled * x_scaled;
                    variance -= var_val;

                    float normalized_value = x_scaled * sqrt(variance + eps);
                    out[idx] = normalized_value + bias;
                }
            }
        """

        # Load CUDA kernels
        cuda.load(layer_norm_kernel)

        # Apply layer norm operation
        layer_norm_output = torch.empty_like(x)
        layer_norm_kernel.grid=(math.ceil(x.size(0) / 64), 1), block=(64, 1), args=(x.data_ptr(), mean.data_ptr(), var.data_ptr(), self.ln1_g.data_ptr(), self.ln1_b.data_ptr(), x.size(0), 1e-7))

        return layer_norm_output

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # Compute mean and variance
        mean = x.mean(dim=1, keepdim=True)
        var = x.var(dim=1, keepdim=True)

        # Apply gelu and layer norm operations
        gelu_output = self.gelu_kernel(x)
        layer_norm_output = self.layer_norm_kernel(gelu_output, mean, var, self.ln1_g, self.ln1_b, x.size(0), 1e-7)

        return layer_norm_output

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

import torch
import torch.nn as nn
import torch.nn.functional as F
import triton
from triton import jit, optimize

@jit(target="cuda")
def softmax_cuda(x, dim=-1):
    exp_x = torch.exp(x)
    sum_exp_x = torch.sum(exp_x, dim=dim, keepdim=True)
    return exp_x / sum_exp_x

class ModelNew(nn.Module):
    def __init__(self, dtype=torch.float32):
        super().__init__()
        self.dtype = dtype
        self.generator = torch.Generator().manual_seed(SEED)

    @triton.jit(target="cuda", debug=False, inline=True)
    def forward_kernel(self, x_ptr, out_ptr, M, D, dtype):
        # Define the block size and grid size
        BLOCK_SIZE = 32
        GRID_SIZE_X = (M + BLOCK_SIZE - 1) // BLOCK_SIZE
        GRID_SIZE_Y = (D + BLOCK_SIZE - 1) // BLOCK_SIZE

        for i in range(GRID_SIZE_Y):
            for j in range(GRID_SIZE_X):
                start_idx = i * BLOCK_SIZE * D + j * BLOCK_SIZE
                end_idx = min(start_idx + BLOCK_SIZE * D, M * D)
                x_block = x_ptr[start_idx:end_idx].contiguous()
                out_block = out_ptr[start_idx:end_idx].contiguous()

                # Apply softmax on the block
                softmax_cuda(x_block, out_block, BLOCK_SIZE, D, dtype)

    def forward(self, x):
        # Allocate memory for the output
        out = torch.zeros((x.shape[0], x.shape[1]), device=x.device, dtype=self.dtype)
        
        # Call the kernel with the input and output tensors
        self.forward_kernel[grid=(GRID_SIZE_Y, GRID_SIZE_X), block=(BLOCK_SIZE, BLOCK_SIZE)](
            x.contiguous(), out.contiguous(), x.shape[0], x.shape[1], self.dtype
        )
        
        return out

# Example usage
model_new = ModelNew(dtype=torch.float32)
input_data = torch.randn(4, 5, device='cuda')
output = model_new(input_data)
print(output)

import torch
import torch.nn as nn
import torch.nn.functional as F

SEED = 500000
M, D, DT = 512, 512, torch.float32

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        self.dtype = dtype
        self.tl = torch.cuda.amp.autocast(dtype=self.dtype)

    def forward(self, x):
        with self.tl:
            # Tile the input tensor
            batch_size, num_samples, num_features = x.size()
            x_tile = x.view(batch_size, num_samples, num_features // 64, 64).permute(0, 1, 3, 2).reshape(batch_size * num_samples, num_features // 64, 64)

            # Fuse softmax operation into one kernel using gemm
            x_fused = torch.matmul(x_tile.unsqueeze(-1), x_tile.permute(0, 2, 1)).squeeze(-1)

            # Apply softmax along the last dimension to each tile
            x_softmaxed = torch.softmax(x_fused, dim=2)

            # Reshape back to the original input shape
            x_reordered = x_softmaxed.reshape(batch_size, num_samples, num_features)

            # Output should be [batch_size, num_samples, num_features]
            return x_reordered

# Example usage:
if __name__ == "__main__":
    model = ModelNew()
    input_tensor = torch.randn(1, M, D, device='cuda')
    output = model(input_tensor)
    print(output.shape)  # Should be [1, 512, 512]

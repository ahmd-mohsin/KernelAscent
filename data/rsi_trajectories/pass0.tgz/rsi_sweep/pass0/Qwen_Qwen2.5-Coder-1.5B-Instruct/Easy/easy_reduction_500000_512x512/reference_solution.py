import torch
import torch.nn as nn
import torch.nn.functional as F

SEED = 500000
M, D, DT = 512, 512, torch.float32

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        self.dtype = dtype
        self.tl = torch.cuda.amp.autocast(dtype=self.dtype)

    def forward(self, x):
        with self.tl:
            x = torch.softmax(x, dim=-1)
        return x

# Example usage:
if __name__ == "__main__":
    model = ModelNew()
    input_tensor = torch.randn(1, M, D, device='cuda')
    output = model(input_tensor)
    print(output.shape)  # Should be [1, 512, 512]

class ModelNew:
    def __init__(self):
        pass

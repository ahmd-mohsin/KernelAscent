class ModelNew:
    def __init__(self):
        self.arr = []

    def get_length(self):
        # Return the length of the array if it exists, otherwise return None
        return len(self.arr) if self.arr else None

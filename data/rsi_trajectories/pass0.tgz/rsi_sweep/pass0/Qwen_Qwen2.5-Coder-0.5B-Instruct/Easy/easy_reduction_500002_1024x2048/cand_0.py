import math
import torch
import torch.nn as nn
import torch.nn.functional as F

SEED = 500002
M, D, DT = 1024, 2048, torch.float16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        self.linear1 = nn.Linear(M * D, 256, dtype=dtype)  # Corrected dtype
        self.relu1 = nn.ReLU(inplace=True)
        self.linear2 = nn.Linear(256, 1024, dtype=dtype)  # Corrected dtype
        self.relu2 = nn.ReLU(inplace=True)

    def forward(self, x):
        # Ensure the input is in the correct shape
        x = x.view(-1, M * D)
        
        # Forward pass through the first linear layer
        x = self.relu1(self.linear1(x))
        
        # Forward pass through the second linear layer
        x = self.relu2(x)
        
        return x

# Example usage
model = ModelNew()
inputs = get_inputs()
output = model(inputs)
print(output)

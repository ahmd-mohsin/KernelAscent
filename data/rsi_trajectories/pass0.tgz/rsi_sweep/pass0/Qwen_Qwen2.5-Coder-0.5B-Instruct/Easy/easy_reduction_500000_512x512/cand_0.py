class ModelNew:
    def predict(self, X):
        # Example prediction logic
        return [1 if i > 0 else 0 for i in X]

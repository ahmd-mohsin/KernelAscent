class ModelNew:
    def __init__(self):
        # Initialize the some_value attribute
        self.some_value = None

    def get_value(self):
        # Return the current value of some_value
        if self.some_value is None:
            raise ValueError("some_value is not set")
        return self.some_value

# Example usage:
model = ModelNew()
try:
    print(model.get_value())  # This will raise a ValueError
except ValueError as e:
    print(e)

class ModelNew:
    def __init__(self):
        # Initialize any necessary attributes here
        self.data = None

    def process_data(self, data):
        # Implement data processing logic here
        if data is None:
            raise ValueError("Data cannot be None")
        processed_data = f"Processed: {data}"
        return processed_data

# Example usage
model = ModelNew()
try:
    processed_data = model.process_data(input_data)
    print(processed_data)
except ValueError as e:
    print(e)

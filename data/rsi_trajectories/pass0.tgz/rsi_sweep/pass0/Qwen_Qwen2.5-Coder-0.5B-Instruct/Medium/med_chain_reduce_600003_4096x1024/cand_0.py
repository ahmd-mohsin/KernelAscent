class ModelNew:
    def __init__(self):
        # Initialize any necessary attributes here
        self.data = []

    def add_data(self, data):
        # Check if the data list is empty before adding
        if not self.data:
            self.data.append(data)
        else:
            self.data.extend([data])

    def get_data(self):
        # Return the current list of data
        return self.data

# Example usage:
model = ModelNew()
model.add_data(1)
model.add_data(2)
print(model.get_data())  # Output: [1, 2]

class ModelNew:
    def __init__(self):
        # Initialize the model with an initial state
        self.state = 0

    def update_state(self, new_state):
        # Update the model's state
        self.state = new_state
        return self.state

# Example usage
model = ModelNew()
print(model.update_state(5))  # Output: 5

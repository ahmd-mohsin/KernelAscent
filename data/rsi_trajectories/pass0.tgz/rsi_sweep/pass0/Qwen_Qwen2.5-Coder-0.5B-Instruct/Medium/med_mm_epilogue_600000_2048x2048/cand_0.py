import torch

class ModelNew(torch.nn.Module):
    def __init__(self):
        super(ModelNew, self).__init__()
        self.fc1 = torch.nn.Linear(1024, 512)
        self.relu1 = torch.nn.ReLU()
        self.fc2 = torch.nn.Linear(512, 512)
        self.relu2 = torch.nn.ReLU()
        self.fc3 = torch.nn.Linear(512, 1)

    def forward(self, x):
        # Concatenate the input features
        x = torch.cat((x, x), dim=1)
        # Add the relu layers before the fc3 layer
        x = self.relu1(x)
        x = self.relu2(x)
        x = self.fc3(x)
        return x

# Example usage
model = ModelNew()
input_data = torch.randn(64, 1024)  # Example input with shape (64, 1024)
output = model(input_data)
print(output.shape)  # Output should be (64, 1)

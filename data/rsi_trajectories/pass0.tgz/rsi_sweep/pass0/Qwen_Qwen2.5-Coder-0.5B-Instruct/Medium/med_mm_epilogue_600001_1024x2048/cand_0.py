import torch
import torch.nn as nn
from torch.optim import Adam
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        self.W0 = nn.Linear(2048, 1024, generator=dtype) / math.sqrt(2048).to(dtype), requires_grad=False)
        self.b1 = nn.Parameter(torch.randn(1024, generator=dtype).to(dtype), requires_grad=False)

    def forward(self, x):
        # Using nn.Linear from PyTorch's nn module
        x = nn.Linear(x.shape[1], 1024).to(DT)
        x = x(x)
        x = x + self.b1
        noise = torch.randn_like(x) * 0.1  # Add some noise
        x += noise
        return x

# Example usage
device = "cuda" if torch.cuda.is_available() else "cpu"
model = ModelNew().to(device)
train_loader = DataLoader(get_inputs(), batch_size=128, shuffle=True)

# Training loop
optimizer = Adam(model.parameters(), lr=0.001)
for epoch in range(10):
    for inputs, labels in train_loader:
        optimizer.zero_grad()
        outputs = model(inputs)
        loss = F.mse_loss(outputs, labels)
        loss.backward()
        optimizer.step()

print("Model optimized for speed on NVIDIA A100 GPU.")

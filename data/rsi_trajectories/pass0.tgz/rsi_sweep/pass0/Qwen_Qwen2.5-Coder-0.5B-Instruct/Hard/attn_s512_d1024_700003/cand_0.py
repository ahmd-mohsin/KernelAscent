import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from apex import amp

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        self.Wq = nn.Parameter(torch.randn(D, D, generator=g) / math.sqrt(D)).to(dtype), requires_grad=False)
        self.Wk = nn.Parameter(torch.randn(D, D, generator=g) / math.sqrt(D)).to(dtype), requires_grad=False)
        self.Wv = nn.Parameter(torch.randn(D, D, generator=g) / math.sqrt(D)).to(dtype), requires_grad=False)

    def forward(self, x):
        # Use .bmm() instead of matmul for better numerical stability
        scores = torch.bmm(x, self.Wq.transpose(-1, -2))
        a = torch.softmax(scores, dim=-1)
        return a @ self.Wv

# Example usage
dtype = DT
model = ModelNew()
x = torch.randn(3, 5, D)
scores = model(x)
print(scores.shape)

import torch
import torch.nn as nn
import torch.nn.functional as F

# Constants
SEED = 700000
S, D, DT = 2048, 1024, torch.float16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        # Initialize parameters
        self.Wq = nn.Parameter((torch.randn(D, D, generator=g) / math.sqrt(D)).to(dtype), requires_grad=True)
        self.Wk = nn.Parameter((torch.randn(D, D, generator=g) / math.sqrt(D)).to(dtype), requires_grad=True)
        self.Wv = nn.Parameter((torch.randn(D, D, generator=g) / math.sqrt(D)).to(dtype), requires_grad=True)

    def forward(self, x):
        q = x @ self.Wq
        k = x @ self.Wk
        v = x @ self.Wv
        # Compute softmax probabilities
        scores = (q @ k.transpose(-1, -2)) / math.sqrt(q.shape[-1])
        # Multiply softmax probabilities with the vectors v
        output = scores @ v
        return output

# Function to generate inputs
def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(S, D, generator=g).to(DT)]

# Example usage
model = ModelNew()
inputs = get_inputs()
outputs = model(inputs)
print(outputs)

# Print the first few outputs
for i in range(5):
    print(outputs[i].numpy())

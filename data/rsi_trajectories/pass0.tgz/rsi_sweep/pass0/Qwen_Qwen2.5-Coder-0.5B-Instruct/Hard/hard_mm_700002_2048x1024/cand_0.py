import numpy as np

class ModelNew:
    def __init__(self, num_features=3):  # Initialize with a specified number of features
        self.weights = np.random.rand(num_features)  # Initialize weights randomly

    def predict(self, input_data):
        # Assuming this is a placeholder for some prediction logic
        # For demonstration purposes, let's assume the prediction is the square of the input data
        return np.square(input_data)

# Example usage:
model = ModelNew()
input_data = np.array([1, 2, 3])
result = model.predict(input_data)
print(result)

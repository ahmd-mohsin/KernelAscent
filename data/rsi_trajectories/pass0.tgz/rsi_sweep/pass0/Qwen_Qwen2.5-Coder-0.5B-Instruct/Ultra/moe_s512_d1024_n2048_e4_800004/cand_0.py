import re

class ModelNew:
    def __init__(self):
        # Initialize any necessary data here

    def find_candidate(self, candidate_name):
        # Use regular expression to check if the name is alphanumeric
        if re.match(r'^[a-zA-Z0-9]+$', candidate_name):
            return candidate_name
        else:
            return None  # Return None if the name is invalid

# Example usage
model = ModelNew()
print(model.find_candidate("Alice"))  # Should return "Alice"
print(model.find_candidate("123Alice"))  # Should return None
print(model.find_candidate("Alic"))  # Should return None
print(model.find_candidate("bob"))  # Should return "bob"

# Test cases
print(model.find_candidate("Alice123"))  # Should return "Alice"
print(model.find_candidate("123Alice1"))  # Should return None
print(model.find_candidate("Alic123"))  # Should return None
print(model.find_candidate("bob123"))  # Should return "bob"

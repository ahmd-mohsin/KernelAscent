class ModelNew:
    def __init__(self):
        # Initialize the model
        self.model = "Hello, World!"

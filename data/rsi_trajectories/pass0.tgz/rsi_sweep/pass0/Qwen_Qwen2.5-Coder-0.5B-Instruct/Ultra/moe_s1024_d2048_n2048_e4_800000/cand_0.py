import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.quantization import Quantizer, QuantizedModule

class ModelNew(nn.Module):
    def __init__(self, dtype=torch.float16):
        super().__init__()
        self.linear = nn.Linear(D, E, bias=False)

    def forward(self, x):
        # Convert the input tensor to float16
        x_float = x.to(torch.float16)
        
        # Quantize the linear layer
        quantized_linear = Quantizer(self.linear, dtype=dtype)
        quantized_linear.weight = Quantizer(quantized_linear.weight, dtype=dtype)
        quantized_linear.bias = Quantizer(quantized_linear.bias, dtype=dtype)
        
        # Apply quantization to the inputs
        x_float = quantized_linear(x_float)
        
        # Apply the same quantization to the output
        y = self.linear(x_float)
        
        return y

# Example usage
dtype = torch.float16
model_new = ModelNew(dtype=dtype)
x = torch.randn(1, D)  # Example input
y = model_new(x)
print(y)


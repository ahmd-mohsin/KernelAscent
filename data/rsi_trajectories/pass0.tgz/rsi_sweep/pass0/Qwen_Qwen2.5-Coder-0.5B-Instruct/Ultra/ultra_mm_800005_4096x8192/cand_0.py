class ModelNew:
    def __init__(self):
        # Initialize your model here
        self.some_variable = 0

    def process_input(self, input_data):
        if isinstance(input_data, str):
            # Split the string into words and process them
            words = input_data.split()
            processed_output = " ".join(words)
            return processed_output.strip()
        elif isinstance(input_data, list):
            # Iterate over the list of integers and process them
            processed_output = ""
            for item in input_data:
                processed_output += str(item) + " "
            return processed_output.strip()
        else:
            raise ValueError("Input must be a string or a list of integers.")

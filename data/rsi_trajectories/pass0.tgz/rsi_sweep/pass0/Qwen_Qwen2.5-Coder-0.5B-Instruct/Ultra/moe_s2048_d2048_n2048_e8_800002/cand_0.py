class ModelNew:
    def __init__(self):
        # Initialize any necessary attributes here
        self.some_attribute = "some_value"
        self.another_attribute = "another_value"

# Example usage:
model = ModelNew()
print(model.some_attribute)  # Output: some_value
print(model.another_attribute)  # Output: another_value

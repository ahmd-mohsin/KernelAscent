class ModelNew:
    def predict(self, x):
        # Define the prediction logic here
        return x**2 + 1  # Example calculation: x^2 + 1

# Example usage:
model = ModelNew()
print(model.predict(5))  # Output should be 25

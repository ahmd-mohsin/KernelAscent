import torch
import torch.nn as nn
from torch.cuda.amp import autocast
from tritonclient.utils import *
from tritonclient.http import *

# Define the SEED constant
SEED = 42

class ModelNew(nn.Module):
    def __init__(self, dtype=torch.float16):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.b0 = nn.Parameter(torch.randn(2048, generator=g).to(dtype), requires_grad=False)

    def forward(self, x):
        # Ensure input and bias are on the same device and data type
        x = x.to(self.b0.dtype).to(self.b0.device)
        
        # Check if the input shape matches the expected shape
        if x.shape[1] != self.b0.shape[0]:
            raise ValueError(f"Input shape {x.shape} does not match expected shape [batch_size, 2048]")
        
        x = x + self.b0
        x = torch.nn.functional.gelu(x)
        return x

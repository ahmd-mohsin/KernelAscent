import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.cuda.amp import autocast, GradScaler
import torch.jit
import torch._inductor.config as config

SEED = 500005
M, D, DT = 1024, 2048, torch.bfloat16

@torch.jit.script
def fused_forward(x, b0):
    with autocast(dtype=b0.dtype):
        x = x.add(b0)
        x = F.gelu(x)
        x = torch.relu(x)
    return x

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.b0 = nn.Parameter(torch.randn(2048, generator=g).to(dtype), requires_grad=False)

    def forward(self, x):
        return fused_forward(x, self.b0)

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

# Additional optimizations for better performance
def optimized_fused_forward(x, b0):
    with autocast(dtype=b0.dtype):
        x = x + b0
        x = F.gelu(x)
        x = torch.relu(x)
    return x

class OptimizedModelNew(ModelNew):
    def forward(self, x):
        return optimized_fused_forward(x, self.b0)

# Example usage
model = OptimizedModelNew()
inputs = get_inputs()

# Run the model
output = model(inputs[0])
print(output.shape)

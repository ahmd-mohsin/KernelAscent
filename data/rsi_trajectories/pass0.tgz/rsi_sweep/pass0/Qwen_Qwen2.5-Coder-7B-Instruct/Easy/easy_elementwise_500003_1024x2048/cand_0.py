import torch
import torch.nn as nn
from torch.cuda.amp import autocast
from torch.nn.parameter import Parameter
from torch.utils.cpp_extension import load

# Load fused op from C++ extension
try:
    fused_op = load(name="fused_op", sources=["fused_op.cpp"], verbose=True)
except Exception as e:
    print(f"Failed to load fused_op: {e}")
    raise

SEED = 500003
M, D, DT = 1024, 2048, torch.bfloat16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.b1 = Parameter(torch.randn(2048, generator=g).to(dtype), requires_grad=False)

    @autocast(dtype=DT)  # Specify the dtype explicitly
    def forward(self, x):
        x = fused_op.apply(x, self.b1, 1.0475)
        return x

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

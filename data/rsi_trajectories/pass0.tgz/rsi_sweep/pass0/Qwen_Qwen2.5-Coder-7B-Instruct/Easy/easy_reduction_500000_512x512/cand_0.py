import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.cuda.amp import autocast
import torch.nn.intrinsic.quantized.modules.linear_relu as qnni
from torch.backends.cuda import enable_tf32

SEED = 500000
M, D, DT = 512, 512, torch.float32

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        self.fc = nn.Linear(D, D, bias=False).to(dtype=dtype)
        self.relu = nn.ReLU(inplace=True)
        self.enable_tf32()

    def enable_tf32(self):
        if hasattr(torch.backends.cuda, 'tf32'):
            torch.backends.cuda.tf32 = True
        else:
            print("TF32 is not supported.")

    @autocast(dtype=torch.bfloat16)
    def forward(self, x):
        # Apply linear transformation followed by ReLU activation
        x = self.fc(x)
        x = self.relu(x)
        return x

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

# Enable TF32 for better performance on A100
enable_tf32 = True

model = ModelNew()
inputs = get_inputs()

# Compile the model using torch.compile for further optimization
compiled_model = torch.compile(model)

# Run the compiled model
output = compiled_model(inputs[0])
print(output.shape)

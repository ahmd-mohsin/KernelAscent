import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.cuda.amp import autocast
from torch.utils.triton import triton, cdiv

SEED = 500002
M, D, DT = 1024, 2048, torch.float16

@triton.jit
def softmax_kernel(
    X_ptr, 
    Y_ptr,
    stride_x_y, 
    N, 
    BLOCK_SIZE: int = 32,
):
    pid = triton.program_id(0)
    grid_size = cdiv(N, BLOCK_SIZE)

    x_start = pid * BLOCK_SIZE
    x_end = min(x_start + BLOCK_SIZE, N)

    for i in range(x_start, x_end):
        max_val = -float('inf')
        for j in range(D):
            max_val = max(max_val, X_ptr[i * stride_x_y + j].item())

        sum_exp = 0.0
        for j in range(D):
            exp_val = math.exp(X_ptr[i * stride_x_y + j].item() - max_val)
            sum_exp += exp_val

        for j in range(D):
            Y_ptr[i * stride_x_y + j] = exp_val / sum_exp

@triton.autotune(
    configs=[
        triton.Config({'BLOCK_SIZE': 32}, num_stages=1, num_warps=4),
    ],
    key=['N', 'D'],
)
def softmax_torchscript(X, stride_x_y, N):
    Y = torch.empty_like(X)
    softmax_kernel[grid_of(N), block_of(BLOCK_SIZE)](X, Y, stride_x_y, N)
    return Y

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        pass

    def forward(self, x):
        with autocast(dtype=torch.float32):
            y = softmax_torchscript(x, x.stride(0), M)
        return y.to(DT)

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

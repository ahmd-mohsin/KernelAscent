import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.cuda.amp import autocast
from tritonclient.utils import np_to_triton_dtype
import tritonclient.http as httpclient

SEED = 500004
M, D, DT = 1024, 512, torch.float32

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.ln1_g = nn.Parameter(torch.ones(D, dtype=dtype, device=torch.device('cuda' if torch.cuda.is_available() else 'cpu')), requires_grad=False)
        self.ln1_b = nn.Parameter(torch.zeros(D, dtype=dtype, device=torch.device('cuda' if torch.cuda.is_available() else 'cpu')), requires_grad=False)

    def forward(self, x):
        with autocast(dtype=self.dtype):
            x = F.gelu(x)
            x = F.layer_norm(x, normalized_shape=(D,), weight=self.ln1_g, bias=self.ln1_b)
        return x

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.cuda.amp import autocast
from torch.cuda.amp.grad_scaler import GradScaler
from torch.utils.cpp_extension import load

# Load custom CUDA kernels if available
custom_ops = load(name="custom_ops", sources=["custom_ops.cpp"], verbose=True)

SEED = 800001
M, D, DT = 4096, 4096, torch.float16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.W0 = nn.Parameter((torch.randn(4096, 4096, generator=g) / math.sqrt(4096)).to(dtype), requires_grad=False)
        self.b1 = nn.Parameter(torch.randn(4096, generator=g).to(dtype), requires_grad=False)
        self.W2 = nn.Parameter((torch.randn(4096, 1024, generator=g) / math.sqrt(4096)).to(dtype), requires_grad=False)
        self.rms3_w = nn.Parameter(torch.randn(1024, generator=g).to(dtype), requires_grad=False)

    def forward(self, x):
        x = x @ self.W0
        x = x + self.b1
        x = x @ self.W2
        with autocast(enabled=torch.is_autocast_enabled()):
            _xf = x.float()
            mean_var = _xf.pow(2).mean(-1, keepdim=True) + 1e-6
            rsqrt_mean_var = torch.rsqrt(mean_var)
            x = (_xf * rsqrt_mean_var).to(x.dtype) * self.rms3_w
        return x

def fused_forward(x, W0, b1, W2, rms3_w):
    # Custom fused forward pass using CUDA kernels
    return custom_ops.fused_forward(x, W0, b1, W2, rms3_w)

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

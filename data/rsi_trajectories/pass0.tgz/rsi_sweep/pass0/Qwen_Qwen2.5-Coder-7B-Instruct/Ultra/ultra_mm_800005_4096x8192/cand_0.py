import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.cuda.amp import autocast, GradScaler

SEED = 800005
M, D, DT = 4096, 8192, torch.bfloat16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.W0 = nn.Parameter((torch.randn(8192, 4096, generator=g) / math.sqrt(8192)).to(dtype), requires_grad=False)
        self.W2 = nn.Parameter((torch.randn(4096, 4096, generator=g) / math.sqrt(4096)).to(dtype), requires_grad=False)
        self.ln3_g = nn.Parameter(torch.randn(4096, generator=g).to(dtype), requires_grad=False)
        self.ln3_b = nn.Parameter(torch.randn(4096, generator=g).to(dtype), requires_grad=False)

    def forward(self, x):
        with autocast(dtype=DT):  # Ensure autocast uses the specified dtype
            x = F.linear(x, self.W0)  # Use self.W0 directly, which is already in the correct dtype
            x = F.gelu(x)
            x = F.linear(x, self.W2)  # Use self.W2 directly, which is already in the correct dtype
            x = F.layer_norm(x, normalized_shape=x.size(-1), weight=self.ln3_g, bias=self.ln3_b)
        return x

import math
import torch
import torch.nn as nn
import torch.nn.functional as F

class ModelNew(nn.Module):
    def __init__(self, dtype=torch.float16):
        super().__init__()
        g = torch.Generator().manual_seed(42)  # Use a fixed seed for reproducibility
        self.Wr = nn.Parameter((torch.randn(D, E, generator=g) / math.sqrt(D)).to(dtype), requires_grad=False)
        self.We = nn.Parameter((torch.randn(N, E, D, generator=g) / math.sqrt(D)).to(dtype), requires_grad=False)

    def forward(self, x):
        with torch.cuda.amp.autocast(enabled=True):
            gate = torch.softmax(x @ self.Wr, dim=-1)
            outs = torch.bmm(gate, self.We.view(N, -1))
            y = F.gelu(outs.sum(dim=1))
            return y

def get_inputs():
    g = torch.Generator().manual_seed(42 + 12345)  # Use a fixed seed for reproducibility
    return [torch.randn(S, D, generator=g).to(torch.float16)]

# Define the constants
D = 128
E = 32
N = 10
S = 64
DT = torch.float16
SEED = 42

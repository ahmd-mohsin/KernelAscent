import torch
from torch.cuda.amp import autocast
from torch.nn.modules.module import Module
from torch.nn.parameter import Parameter
from torch.nn.functional import gelu, layer_norm

class ModelNew(Module):
    def __init__(self, dtype=torch.float16):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.W0 = Parameter((torch.randn(4096, 4096, generator=g) / math.sqrt(4096)).to(dtype), requires_grad=False)
        self.W2 = Parameter((torch.randn(4096, 512, generator=g) / math.sqrt(4096)).to(dtype), requires_grad=False)
        self.ln3_g = Parameter(torch.randn(512, generator=g).to(dtype), requires_grad=False)
        self.ln3_b = Parameter(torch.randn(512, generator=g).to(dtype), requires_grad=False)

    def forward(self, x):
        with autocast(enabled=True):
            x = torch.matmul(x, self.W0)
            x = gelu(x)
            x = torch.matmul(x, self.W2)
            x = layer_norm(x, normalized_shape=(x.size(-1,),), weight=self.ln3_g, bias=self.ln3_b)
        return x

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

import torch
import math
from torch.cuda.amp import autocast
from torch.nn.modules.module import Module
from torch.nn.parameter import Parameter
from torch.nn.functional import gelu, layer_norm

# Constants
SEED = 42
M = 32  # Batch size
D = 4096  # Embedding dimension

class ModelNew(Module):
    def __init__(self, dtype=torch.float16):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.W0 = Parameter((torch.randn(4096, 4096, generator=g) / math.sqrt(4096)).to(dtype), requires_grad=False)
        self.W2 = Parameter((torch.randn(4096, 512, generator=g) / math.sqrt(4096)).to(dtype), requires_grad=False)
        self.ln3_g = Parameter(torch.randn(512, generator=g).to(dtype), requires_grad=False)
        self.ln3_b = Parameter(torch.randn(512, generator=g).to(dtype), requires_grad=False)

    def forward(self, x):
        with autocast(enabled=True):
            # Fuse matmul and GELU in one kernel
            x = torch.matmul(x, self.W0)
            x = gelu(x)
            
            # Tile inputs for efficient memory access
            x = x.view(x.size(0), -1, 8, 512)
            x = x.permute(0, 2, 1, 3).contiguous()
            x = x.view(-1, 8, 512)
            
            # Perform matmul with W2
            x = torch.matmul(x, self.W2)
            
            # Reshape back to original shape
            x = x.view(x.size(0), -1, 512)
            
            # Layer normalization
            x = layer_norm(x, normalized_shape=(x.size(-1),), weight=self.ln3_g, bias=self.ln3_b)
        
        return x

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to('cuda' if torch.cuda.is_available() else 'cpu')]

import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.cuda.amp import autocast, GradScaler
from flash_attn import flash_attention_forward

SEED = 800002
S, D, N, E, DT = 2048, 2048, 2048, 8, torch.float16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.Wr = nn.Parameter((torch.randn(D, E, generator=g) / math.sqrt(D)).to(dtype))
        self.We = nn.Parameter((torch.randn(N, E, D, generator=g) / math.sqrt(D)).to(dtype))

    def forward(self, x):
        with autocast(enabled=True):
            gate = torch.softmax(x @ self.Wr, dim=-1)
            outs = torch.einsum('bnd,nel->bned', x, self.We)
            y = (gate.unsqueeze(-1) * outs).sum(dim=1)
        return F.gelu(y)

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(S, D, generator=g).to(DT)]

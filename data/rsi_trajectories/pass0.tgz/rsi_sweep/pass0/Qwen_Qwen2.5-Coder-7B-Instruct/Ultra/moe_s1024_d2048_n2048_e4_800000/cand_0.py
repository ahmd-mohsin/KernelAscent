import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.cuda.amp import autocast
from torch.utils.cpp_extension import load

# Assuming you have compiled the fused op using the provided C++ code and it is named 'fused_ops.so'
fused_ops = load(name="fused_ops", sources=["fused_ops.cpp"], extra_cflags=["-O3"])

SEED = 800000
S, D, N, E, DT = 1024, 2048, 2048, 4, torch.float16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.Wr = nn.Parameter((torch.randn(D, E, generator=g) / math.sqrt(D)).to(dtype), requires_grad=False)
        self.We = nn.Parameter((torch.randn(E, D, N, generator=g) / math.sqrt(D)).to(dtype), requires_grad=False)

    def forward(self, x):
        with autocast(dtype=torch.float32):
            gate = torch.softmax(x @ self.Wr, dim=-1)
        outs = torch.stack([x @ self.We[e] for e in range(E)], dim=0)
        # Ensure that the fused operation is applied correctly
        y = fused_ops.apply(gate.transpose(0, 1).unsqueeze(-1).half(), outs.half()).sum(0)
        return F.gelu(y)

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(S, D, generator=g).to(DT)]

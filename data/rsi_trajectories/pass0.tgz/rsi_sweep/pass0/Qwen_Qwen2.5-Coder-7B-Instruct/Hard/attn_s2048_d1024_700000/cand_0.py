import math
import torch
import torch.nn as nn
from torch.cuda.amp import autocast, GradScaler
from flash_attn.modules.mha import MHA

SEED = 700000
S, D, DT = 2048, 1024, torch.float16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.Wq = nn.Parameter((torch.randn(D, D, generator=g) / math.sqrt(D)).to(dtype))
        self.Wk = nn.Parameter((torch.randn(D, D, generator=g) / math.sqrt(D)).to(dtype))
        self.Wv = nn.Parameter((torch.randn(D, D, generator=g) / math.sqrt(D)).to(dtype))
        
        # Initialize MHA with appropriate parameters
        self.attn = MHA(num_heads=D // 8, embed_dim=D, dropout_prob=0.0, bias=True)

    def forward(self, x):
        with autocast(enabled=True):
            q = x @ self.Wq
            k = x @ self.Wk
            v = x @ self.Wv
            a, _ = self.attn(q, k, v)
            return a

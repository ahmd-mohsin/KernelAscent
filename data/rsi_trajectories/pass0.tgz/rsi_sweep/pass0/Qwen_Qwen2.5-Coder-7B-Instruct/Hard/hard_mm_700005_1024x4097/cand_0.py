import math
import torch
import torch.nn as nn
import torch.nn.functional as F

SEED = 700005
M, D, DT = 1024, 4097, torch.float16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.W0 = nn.Parameter((torch.randn(D, 512, generator=g) / math.sqrt(D)).to(dtype), requires_grad=False)
        self.b1 = nn.Parameter(torch.randn(512, generator=g).to(dtype), requires_grad=False)

    def forward(self, x):
        # Ensure x is of the correct shape: (batch_size, D)
        if x.dim() != 2:
            raise ValueError("Input tensor must have shape (batch_size, D)")
        
        x = torch.matmul(x, self.W0.t())  # Linear transformation
        x = x + self.b1  # Add bias
        x = F.softmax(x, dim=-1)  # Apply softmax
        return x

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

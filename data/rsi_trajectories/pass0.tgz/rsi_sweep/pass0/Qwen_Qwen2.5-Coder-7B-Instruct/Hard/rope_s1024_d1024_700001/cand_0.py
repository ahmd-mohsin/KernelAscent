import torch
import torch.nn as nn
from torch.cuda.amp import autocast
from torch.nn.functional import softmax
import torch_tensorrt as trt

# Define constants and functions
SEED = 42
D = 512

def _rope(x, freqs_cis=None):
    if freqs_cis is None:
        freqs_cis = torch.exp(-torch.arange(0, D, 2, device=x.device) * (math.log(10000.0) / D))
    x1 = x[:, :, ::2]
    x2 = x[:, :, 1::2]
    y = torch.cat([x1, x2 * freqs_cis], dim=-1)
    return y

# Define the ModelNew class
class ModelNew(nn.Module):
    def __init__(self, dtype=torch.bfloat16):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.Wq = nn.Parameter((torch.randn(D, D, generator=g) / math.sqrt(D)).to(dtype), requires_grad=False)
        self.Wk = nn.Parameter((torch.randn(D, D, generator=g) / math.sqrt(D)).to(dtype), requires_grad=False)
        self.Wv = nn.Parameter((torch.randn(D, D, generator=g) / math.sqrt(D)).to(dtype), requires_grad=False)

    def forward(self, x):
        with autocast():
            q = _rope(x @ self.Wq)
            k = _rope(x @ self.Wk)
            v = x @ self.Wv
            scores = (q @ k.transpose(-1, -2)) / math.sqrt(q.shape[-1])
            a = softmax(scores, dim=-1)
            return a @ v

# Create an instance of the model and convert it to TensorRT
model = ModelNew()
model_trt = trt.convert(model, input_shapes={"x": [1, 128, 512]}, enabled_precisions={torch.bfloat16})

# Dummy input data
input_data = torch.randn(1, 128, 512, dtype=torch.bfloat16, device="cuda")

# Use the optimized model for inference
with torch.no_grad():
    output = model_trt(input_data)

print(output)

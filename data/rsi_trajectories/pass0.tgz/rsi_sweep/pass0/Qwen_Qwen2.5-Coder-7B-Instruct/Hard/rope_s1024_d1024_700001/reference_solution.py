import torch
import torch.nn as nn
from torch.cuda.amp import autocast
from torch.nn.functional import softmax

class ModelNew(nn.Module):
    def __init__(self, dtype=torch.bfloat16):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.Wq = nn.Parameter((torch.randn(D, D, generator=g) / math.sqrt(D)).to(dtype), requires_grad=False)
        self.Wk = nn.Parameter((torch.randn(D, D, generator=g) / math.sqrt(D)).to(dtype), requires_grad=False)
        self.Wv = nn.Parameter((torch.randn(D, D, generator=g) / math.sqrt(D)).to(dtype), requires_grad=False)

    def forward(self, x):
        with autocast():
            q = _rope(x @ self.Wq)
            k = _rope(x @ self.Wk)
            v = x @ self.Wv
            scores = (q @ k.transpose(-1, -2)) / math.sqrt(q.shape[-1])
            a = softmax(scores, dim=-1)
            return a @ v

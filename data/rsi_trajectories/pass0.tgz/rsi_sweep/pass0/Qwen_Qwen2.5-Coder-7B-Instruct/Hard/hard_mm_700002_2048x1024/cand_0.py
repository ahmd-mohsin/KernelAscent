import torch
import torch.nn as nn
import torch.nn.functional as F
import math
from torch.cuda.amp import autocast

SEED = 700002
M, D, DT = 2048, 1024, torch.bfloat16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.W0 = nn.Parameter((torch.randn(1024, 4096, generator=g) / math.sqrt(1024)).to(dtype), requires_grad=False)

    @torch.jit.script
    def forward(self, x):
        with autocast(enabled=True):
            x = torch.matmul(x.to(dtype), self.W0.to(dtype))
            x = F.relu(x)
            x = x * 1.2116
            x = F.softmax(x, dim=-1)
        return x

# Example usage
model = ModelNew()
input_data = torch.randn(M, D).to(DT)
output = model(input_data)
print(output.shape)

import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.cuda.amp import autocast, GradScaler
from torch.utils.triton import cdiv

SEED = 600000
M, D, DT = 2048, 2048, torch.bfloat16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.W0 = nn.Parameter((torch.randn(2048, 512, generator=g) / math.sqrt(2048)).to(dtype), requires_grad=False)

    def forward(self, x):
        with autocast(dtype=torch.float32):
            x = x.to(torch.float32) @ self.W0.to(torch.float32)
        x = F.relu(x.to(DT))
        return x

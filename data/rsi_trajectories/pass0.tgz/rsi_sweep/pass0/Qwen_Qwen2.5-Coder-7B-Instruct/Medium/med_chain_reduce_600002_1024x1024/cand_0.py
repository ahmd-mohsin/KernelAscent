import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.cuda.amp import autocast
import torch.nn.modules.utils as utils
import triton
import triton.language as tl

SEED = 600002
M, D, DT = 1024, 1024, torch.float16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        pass

    @triton.jit
    def fused_forward_kernel(
        X_ptr,          # Pointer to input tensor
        Out_ptr,        # Pointer to output tensor
        N,              # Number of rows in the input tensor
        D,              # Number of columns in the input tensor
        BLOCK_SIZE_M: tl.constexpr,  # Block size along M dimension
        BLOCK_SIZE_N: tl.constexpr,  # Block size along N dimension
    ):
        pid = tl.program_id(0)  # Unique ID for each program instance
        grid_m = tl.cdiv(N, BLOCK_SIZE_M)
        row = pid // grid_m
        col = pid % grid_m

        # Load data
        x = tl.load(X_ptr + row * D * DT.itemsize + col * DT.itemsize, dt=DT)

        # Apply ReLU and scale
        x = tl.where(x > 0, x, 0)
        x *= 1.4263

        # Apply ReLU again
        x = tl.where(x > 0, x, 0)

        # Apply Softmax
        exp_x = tl.exp(x - tl.max(x))
        sum_exp_x = tl.sum(exp_x)
        out = exp_x / sum_exp_x

        # Store result
        tl.store(Out_ptr + row * D * DT.itemsize + col * DT.itemsize, out, dt=DT)

    def forward(self, x):
        x = x.to(DT)
        y = torch.empty_like(x)
        self.fused_forward_kernel[(M, D), (BLOCK_SIZE_M, BLOCK_SIZE_N)](x, y, x.shape[0], x.shape[1], BLOCK_SIZE_M=32, BLOCK_SIZE_N=32)
        return y

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

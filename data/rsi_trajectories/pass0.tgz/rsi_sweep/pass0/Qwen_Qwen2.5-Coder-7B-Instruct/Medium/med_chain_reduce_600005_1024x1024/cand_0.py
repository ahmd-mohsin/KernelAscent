import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.cuda.amp import autocast

SEED = 600005
M, D, DT = 1024, 1024, torch.bfloat16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.rms2_w = nn.Parameter(torch.randn(1024, generator=g).to(dtype), requires_grad=False)

    def forward(self, x):
        x = x.contiguous()
        y = torch.empty_like(x)
        
        mean = torch.mean(torch.square(x), dim=1, keepdim=True)
        mean = torch.rsqrt(mean + 1e-6)
        
        y = x * mean * self.rms2_w
        
        return y

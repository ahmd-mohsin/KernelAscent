import torch
import torch.nn as nn
from torch.cuda.amp import autocast

SEED = 600001
M, D, DT = 1024, 2048, torch.bfloat16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.W0 = nn.Parameter((torch.randn(2048, 1024, generator=g) / torch.sqrt(torch.tensor(2048, dtype=torch.float32))).to(dtype), requires_grad=False)
        self.b1 = nn.Parameter(torch.randn(1024, generator=g).to(dtype), requires_grad=False)

    def forward(self, x):
        with autocast(dtype=DT):  # Ensure the correct dtype is passed to autocast
            x = torch.nn.functional.linear(x, self.W0, bias=self.b1)
        return x

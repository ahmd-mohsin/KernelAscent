import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.cuda.amp import autocast, GradScaler

SEED = 600003
M, D, DT = 4096, 1024, torch.bfloat16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        self.dtype = dtype

    def forward(self, x):
        with autocast(dtype=torch.float32):
            x = F.gelu(x)
            x = F.gelu(x)
        x = F.softmax(x, dim=-1, dtype=self.dtype)
        return x

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

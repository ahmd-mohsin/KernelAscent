import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.cuda.amp import autocast, GradScaler
import triton
import triton.language as tl

SEED = 600003
M, D, DT = 4096, 1024, torch.bfloat16

@triton.jit
def fused_gelu_softmax_kernel(
    X, Y, BLOCK_SIZE: tl.constexpr,
):
    pid = tl.program_id(axis=0)
    grid_size = tl.cdiv(X.shape[0], BLOCK_SIZE)

    i = pid * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
    mask = i < X.shape[0]
    x = X[i]

    # Apply GELU activation
    gelu_coefficient = 0.7978845608
    gelu_constant = 0.044715
    gelu_x = x * (1.0 + gelu_coefficient * x * (0.5 + 0.044715 * x * x))

    # Apply softmax
    max_val = tl.max(gelu_x, axis=-1, keepdim=True)
    exp_sum = tl.exp(gelu_x - max_val)
    y = exp_sum / tl.sum(exp_sum, axis=-1, keepdim=True)

    Y[i] = tl.where(mask, y, 0.)

@triton.autotune(
    configs=[
        triton.Config({'BLOCK_SIZE': 128}, num_stages=2, num_warps=4),
        triton.Config({'BLOCK_SIZE': 256}, num_stages=2, num_warps=4),
        triton.Config({'BLOCK_SIZE': 512}, num_stages=2, num_warps=4),
    ],
    key=['BLOCK_SIZE']
)
def fused_gelu_softmax_forward(x, y, BLOCK_SIZE: tl.constexpr):
    fused_gelu_softmax_kernel(x, y, BLOCK_SIZE=BLOCK_SIZE)

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        self.dtype = dtype

    @torch.no_grad()
    def forward(self, x):
        x = x.to(torch.float32)
        y = torch.empty_like(x, device=x.device, dtype=torch.float32)
        fused_gelu_softmax_forward(x, y, BLOCK_SIZE=256)  # Optimal block size for A100
        return y.to(self.dtype)

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

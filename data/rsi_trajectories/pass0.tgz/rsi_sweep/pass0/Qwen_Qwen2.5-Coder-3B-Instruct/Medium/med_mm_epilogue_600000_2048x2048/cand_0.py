import torch
import torch.nn as nn
import torch.nn.functional as F
import triton
import triton.language as tl

SEED = 600000
M, D, DT = 2048, 2048, torch.bfloat16

@triton.jit
def model_forward(
    x: tl.constref(torch.float16),
    W0: tl.constref(torch.float16),
    out: tl.ref(torch.float16),
    N: int,
    M: int,
    D: int,
    BLOCK_SIZE_X: tl.constexpr,
    BLOCK_SIZE_Y: tl.constexpr
):
    # Define threads per block
    tx = tl.program_id(0)
    ty = tl.program_id(1)

    # Compute global coordinates
    x_start = tx * BLOCK_SIZE_X
    y_start = ty * BLOCK_SIZE_Y

    # Load data from global memory
    x_block = tl.load(x[x_start:x_start + BLOCK_SIZE_X, :])
    W0_block = tl.load(W0[:D, y_start:y_start + BLOCK_SIZE_Y])

    # Perform matrix multiplication
    out_block = tl.dot(x_block, W0_block.T)

    # Write back to global memory
    tl.store(out[x_start:x_start + BLOCK_SIZE_X, y_start:y_start + BLOCK_SIZE_Y], out_block)

@triton.jit
def model_forward_kernel(
    x: tl.constref(torch.float16),
    W0: tl.constref(torch.float16),
    out: tl.ref(torch.float16),
    N: int,
    M: int,
    D: int,
    BLOCK_SIZE_X: tl.constexpr,
    BLOCK_SIZE_Y: tl.constexpr
):
    model_forward[BLOCK_SIZE_Y, BLOCK_SIZE_X](
        x, W0, out, N, M, D, BLOCK_SIZE_X, BLOCK_SIZE_Y
    )

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.W0 = nn.Parameter((torch.randn(512, 2048, generator=g) / math.sqrt(512)).to(dtype), requires_grad=False)

    def forward(self, x):
        x = x.contiguous(memory_format=torch.contiguous_format)
        out = torch.empty_like(x, device=x.device, dtype=DT)
        model_forward_kernel[N // BLOCK_SIZE_Y, M // BLOCK_SIZE_X](x, self.W0, out, N, M, D, BLOCK_SIZE_X=64, BLOCK_SIZE_Y=64)
        return out

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

# Test the model
model = ModelNew()
x = get_inputs()[0]
output = model(x)
print(output)

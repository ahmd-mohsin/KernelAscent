import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils import autotune

SEED = 600003
M, D, DT = 4096, 1024, torch.bfloat16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        self.gelu = nn.GELU()
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, x):
        # Ensure the input is on the correct device and dtype
        x = x.to(dtype)
        
        # Fuse gelu and softmax into one kernel using torch.compile
        x = torch.compile(self.gelu(self.gelu(x)))(x)
        x = self.softmax(x)
        return x

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

# Example usage
model = ModelNew()
inputs = get_inputs()
outputs = model(inputs)
print(outputs)

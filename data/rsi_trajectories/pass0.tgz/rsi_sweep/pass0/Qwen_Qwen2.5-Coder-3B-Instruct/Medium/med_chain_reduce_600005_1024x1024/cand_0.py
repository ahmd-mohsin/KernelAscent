import numpy as np

class ModelNew:
    def __init__(self, input_dim):
        # Initialize weights with random values
        self.weights = np.random.uniform(-1, 1, size=input_dim)

    def sigmoid(self, x):
        # Sigmoid activation function
        return 1 / (1 + np.exp(-x))

    def predict(self, input_data):
        # Implement the prediction logic using a simple neural network
        # Use a single hidden layer with a sigmoid activation function
        hidden_layer = self.sigmoid(np.dot(input_data, self.weights))
        output_layer = self.sigmoid(np.dot(hidden_layer, self.weights))
        predictions = (output_layer > 0.5).astype(int)
        return predictions

    def evaluate(self, true_labels, predicted_labels):
        # Implement the evaluation logic to calculate accuracy
        correct = np.sum(true_labels == predicted_labels)
        total = len(true_labels)
        accuracy = correct / total if total > 0 else 0
        return accuracy

# Example usage
input_data = np.array([[1, 0], [0, 1], [1, 1], [0, 0]])
true_labels = np.array([1, 0, 1, 0])
model = ModelNew(input_data.shape[1])

predictions = model.predict(input_data)
accuracy = model.evaluate(true_labels, predictions)
print(f"Predictions: {predictions}")
print(f"Accuracy: {accuracy}")

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.cuda as cuda
import torch.cuda.amp as amp

SEED = 600004
M, D, DT = 1024, 2048, torch.float16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        # Initialize LayerNorm parameters
        self.ln3_g = nn.Parameter(torch.randn(2048, generator=g).to(dtype))
        self.ln3_b = nn.Parameter(torch.randn(2048, generator=g).to(dtype))

    def forward(self, x):
        # Apply ReLU activation and scale/shift
        x = F.relu(x) * 1.1504 * 1.2656
        # Use fused PyTorch op for LayerNorm
        x = torch.nn.functional.layer_norm(x, (x.size(-1),), self.ln3_g, self.ln3_b)
        return x

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

# Example usage
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = ModelNew().to(device)
inputs = get_inputs()
inputs = [input.to(device) for input in inputs]
with amp.autocast():
    output = model(inputs[0])
print(output.shape)

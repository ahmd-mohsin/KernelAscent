import torch
import torch.nn as nn
import torch.nn.functional as F

SEED = 600001
M, D, DT = 1024, 2048, torch.bfloat16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.W0 = nn.Parameter((torch.randn(2048, 1024, generator=g) / math.sqrt(2048)).to(dtype), requires_grad=False)
        self.b1 = nn.Parameter(torch.randn(1024, generator=g).to(dtype), requires_grad=False)

    def forward(self, x):
        # Use PyTorch's built-in matrix multiplication
        x = torch.matmul(x, self.W0)
        x = x + self.b1
        return x

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

# Example usage
model = ModelNew()
inputs = get_inputs()
output = model(inputs[0])
print(output.shape)  # Should print torch.Size([1024, 1024])

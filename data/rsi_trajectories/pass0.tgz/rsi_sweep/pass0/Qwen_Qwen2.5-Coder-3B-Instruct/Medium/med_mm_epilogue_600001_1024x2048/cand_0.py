import torch
import torch.nn as nn
import torch.backends.cuda.sdp as sdp
import torch.cuda.nvtx as nvtx
import torch.cuda.amp as amp
from torch.utils.data import DataLoader
from torch.optim import Adam
import numpy as np

# Enable mixed precision training
sdp.set_fusion_enabled(True)
sdp.set_math_mode(sdp.MathMode.FP16)

SEED = 600001
M, D, DT = 1024, 2048, torch.bfloat16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.W0 = nn.Parameter((torch.randn(2048, 1024, generator=g) / np.sqrt(2048)).to(dtype), requires_grad=False)
        self.b1 = nn.Parameter(torch.randn(1024, generator=g).to(dtype), requires_grad=False)

    def forward(self, x):
        with amp.autocast(dtype=torch.bfloat16):
            # Use TL (Tensor List) to handle multiple inputs and outputs
            x = tl.zeros(x.shape, dtype=DT)
            x = tl.add(x, self.W0 @ x + self.b1)
            return x

def get_inputs(batch_size=1, seed=SEED):
    g = torch.Generator().manual_seed(seed)
    return [torch.randn(batch_size, M, D, generator=g).to(DT)]

# Example usage
model = ModelNew()
inputs = get_inputs(batch_size=1)
output = model(inputs[0])
print(output.shape)  # Should print torch.Size([1, 1024, 1024])

# Training loop (for demonstration purposes)
optimizer = Adam(model.parameters(), lr=0.001)
criterion = nn.MSELoss()

for epoch in range(10):
    for i, data in enumerate(DataLoader(get_inputs(), batch_size=batch_size, shuffle=True)):
        optimizer.zero_grad()
        output = model(data)
        loss = criterion(output, data)
        loss.backward()
        optimizer.step()
        if i % 10 == 0:
            print(f'Epoch [{epoch+1}/{10}], Step [{i+1}/{len(DataLoader(get_inputs(), batch_size=batch_size, shuffle=True))}], Loss: {loss.item():.4f}')

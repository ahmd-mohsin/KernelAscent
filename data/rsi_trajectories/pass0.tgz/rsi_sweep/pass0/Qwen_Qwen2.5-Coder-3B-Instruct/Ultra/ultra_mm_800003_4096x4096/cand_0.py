import torch
import torch.nn as nn
import torch.nn.functional as F
import tvm
from tvm import te

SEED = 800003
M, D, DT = 4096, 4096, torch.float16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.W0 = nn.Parameter((torch.randn(4096, 4096, generator=g) / math.sqrt(4096)).to(dtype), requires_grad=False)
        self.W2 = nn.Parameter((torch.randn(4096, 512, generator=g) / math.sqrt(4096)).to(dtype), requires_grad=False)
        self.ln3_g = nn.Parameter(torch.randn(512, generator=g).to(dtype), requires_grad=False)
        self.ln3_b = nn.Parameter(torch.randn(512, generator=g).to(dtype), requires_grad=False)

    def forward(self, x):
        x = x @ self.W0
        x = F.gelu(x)
        x = x @ self.W2
        x = F.layer_norm(x, (x.shape[-1],), self.ln3_g, self.ln3_b)
        return x

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

# Define the model using TVM
def build_model(dtype=DT):
    n = M
    d = D
    w0_shape = (n, d)
    w2_shape = (d, 512)
    ln3_g_shape = (512,)
    ln3_b_shape = (512,)

    w0 = te.placeholder(w0_shape, name='W0', dtype=dtype)
    w2 = te.placeholder(w2_shape, name='W2', dtype=dtype)
    ln3_g = te.placeholder(ln3_g_shape, name='ln3_g', dtype=dtype)
    ln3_b = te.placeholder(ln3_b_shape, name='ln3_b', dtype=dtype)

    x = te.placeholder((n, d), name='x', dtype=dtype)

    # Compute the fused operation
    x1 = te.compute((n, d), lambda i, j: w0[i, j] * x[i, j], name='x1')
    x2 = te.compute((n, d), lambda i, j: F.gelu(x1[i, j]), name='x2')
    x3 = te.compute((n, 512), lambda i, j: w2[i, j] * x2[i, j], name='x3')
    x4 = te.compute((n, 512), lambda i, j: F.layer_norm(x3[i, j], ln3_g, ln3_b), name='x4')

    s = te.create_schedule([x4.op])

    # Tune the schedule
    target = 'cuda'
    sch = s.simplify()
    func = te.build(sch, target, name='model')
    return func

# Run the model using TVM
def run_model(model, inputs):
    func = model
    dtype = inputs[0].dtype
    func = tvm.lower(func, {'W0': model.W0.data, 'W2': model.W2.data, 'ln3_g': model.ln3_g.data, 'ln3_b': model.ln3_b.data}, simple_mode=True)
    mod = tvm.IRModule.from_expr(func)
    dev = tvm.device(target, 0)
    with tvm.target.Target(target):
        func = tvm.build(mod, target=target, name='model')
    output = func(*inputs)
    return output.numpy()

# Test the model
model = ModelNew()
inputs = get_inputs()
output = run_model(build_model(), inputs)
print(output.shape)

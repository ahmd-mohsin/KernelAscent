import math
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.cuda as cuda
import torch.cuda.comm as comm

SEED = 800001
M, D, DT = 4096, 4096, torch.float16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.W0 = nn.Parameter((torch.randn(4096, 4096, generator=g) / math.sqrt(4096)).to(dtype), requires_grad=False)
        self.b1 = nn.Parameter(torch.randn(4096, generator=g).to(dtype), requires_grad=False)
        self.W2 = nn.Parameter((torch.randn(4096, 1024, generator=g) / math.sqrt(4096)).to(dtype), requires_grad=False)
        self.rms3_w = nn.Parameter(torch.randn(1024, generator=g).to(dtype), requires_grad=False)

    def forward(self, x):
        # Fused operation: matrix multiplication + bias addition + matrix multiplication
        x = torch.ops.aten.mm(x, self.W0)
        x = x + self.b1
        x = torch.ops.aten.mm(x, self.W2)
        
        # Convert to float to perform RMS normalization
        x_float = x.float()
        
        # Compute mean and variance
        mean = x_float.mean(-1, keepdim=True)
        variance = x_float.pow(2).mean(-1, keepdim=True) + 1e-6
        
        # Compute normalized tensor
        x_normalized = (x_float - mean) / torch.rsqrt(variance)
        
        # Reshape for batchwise processing
        x_normalized = x_normalized.view(NUM_BLOCKS, BLOCK_SIZE // WARPS_PER_BLOCK, -1)
        
        # Apply RMS normalization using LayerNorm
        x_final = self.rms3_w.unsqueeze(0).expand_as(x_normalized)
        x_final = x_final * x_normalized
        x_final = torch.nn.functional.layer_norm(x_final, x_final.shape[-1:], eps=1e-6)
        
        # Reshape back to original shape
        x_final = x_final.view(M, -1)
        
        # Convert back to original data type
        return x_final.to(x.dtype)

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

# Example usage
model = ModelNew().cuda()
inputs = get_inputs()
outputs = model(inputs)
print(outputs.shape)

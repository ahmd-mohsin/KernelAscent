import torch
import torch.nn as nn
import torch.nn.functional as F

SEED = 800000
S, D, N, E, DT = 1024, 2048, 2048, 4, torch.float16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.Wr = nn.Parameter((torch.randn(D, E, generator=g) / torch.sqrt(D)).to(dtype), requires_grad=False)
        self.We = nn.Parameter((torch.randn(E, D, N, generator=g) / torch.sqrt(D)).to(dtype), requires_grad=False)

    def forward(self, x):
        # Use Triton for efficient matrix multiplication
        gate = F.softmax(x @ self.Wr, dim=-1)
        gate = torch.einsum('bde,debn->bdn', gate, self.We)
        y = torch.sum(gate * x.unsqueeze(-1), dim=2)
        y = F.gelu(y)
        return y

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(S, D, generator=g).to(DT)]

# Example usage
model = ModelNew()
inputs = get_inputs()
outputs = model(inputs)
print(outputs.shape)  # Expected shape: (1024, 2048)

import torch
import torch.nn as nn
import torch.nn.functional as F

SEED = 800005
M, D, DT = 4096, 8192, torch.bfloat16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.W0 = nn.Parameter(torch.randn(D, M, dtype=dtype) / torch.sqrt(D), requires_grad=False)
        self.W2 = nn.Parameter(torch.randn(M, M, dtype=dtype) / torch.sqrt(M), requires_grad=False)
        self.ln3_g = nn.Parameter(torch.randn(M, dtype=dtype), requires_grad=False)
        self.ln3_b = nn.Parameter(torch.randn(M, dtype=dtype), requires_grad=False)

    def forward(self, x):
        # Use standard PyTorch operations for matrix multiplication and GELU
        x = F.linear(x, self.W0.to(DT), None)
        x = F.gelu(x)

        # Use standard PyTorch operations for matrix multiplication and layer normalization
        x = F.linear(x, self.W2.to(DT), None)
        x = F.layer_norm(x, (x.shape[-1],), self.ln3_g.to(DT), self.ln3_b.to(DT))

        return x

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, dtype=DT)]

# Example usage
model = ModelNew()
inputs = get_inputs()
outputs = model(inputs)
print(outputs.shape)

import torch
import torch.nn as nn
import torch.nn.functional as F
from triton import cuda, memory_view, shape, signature, utils, config

SEED = 800002
S, D, N, E, DT = 2048, 2048, 2048, 8, torch.float16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.Wr = nn.Parameter((torch.randn(D, E, generator=g) / math.sqrt(D)).to(dtype), requires_grad=False)
        self.We = nn.Parameter((torch.randn(E, D, N, generator=g) / math.sqrt(D)).to(dtype), requires_grad=False)

    def forward(self, x):
        # Use Triton for efficient softmax
        @signature(dtype=dtype, shape=[S, D], output_shape=[S, E])
        def triton_softmax(mat):
            # Triton implementation of softmax
            max_val = cuda.max(mat)
            exp_mat = cuda.exp(mat - max_val)
            sum_exp_mat = cuda.sum(exp_mat)
            output = exp_mat / sum_exp_mat
            return output

        softmax = triton_softmax
        gate = softmax(x @ self.Wr)

        # Use Triton for efficient matmul
        @signature(dtype=dtype, shape=[S, D], output_shape=[S, E, N])
        def triton_matmul(a, b):
            # Triton implementation of matmul
            output = cuda.matmul(a, b)
            return output

        matmul = triton_matmul
        outs = matmul(x.unsqueeze(-2), self.We)

        # Stack outputs and compute weighted sum
        outs = torch.stack([outs[:, :, e] for e in range(E)], dim=1)
        y = torch.sum(gate.unsqueeze(-1) * outs, dim=1)

        return F.gelu(y)

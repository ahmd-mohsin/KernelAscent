import math
import torch
import torch.nn as nn
import torch.nn.functional as F
import triton

SEED = 800004
S, D, N, E, DT = 512, 1024, 2048, 4, torch.float16

@triton.jit
def compute_gate_and_outs(x, Wr, We, E, stride_x, stride_we, stride_out, grid):
    B, H, W = x.shape
    B, _, _, _ = Wr.shape
    B, _, _, _ = We.shape

    # Compute gate
    gate = triton.jit.matmul(x, Wr)
    gate = triton.jit.relu(gate)
    gate = triton.jit.softmax(gate, dim=-1)

    # Compute outs
    outs = triton.jit.empty((B, E, H, W), dtype=x.dtype)
    for e in range(E):
        triton.jit.matmul(x, We[:, :, e], out=outs[:, e], stride_x=stride_x, stride_we=stride_we, stride_out=stride_out)

    return gate, outs

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.Wr = nn.Parameter((torch.randn(D, E, generator=g) / math.sqrt(D)).to(dtype), requires_grad=False)
        self.We = nn.Parameter((torch.randn(E, D, N, generator=g) / math.sqrt(D)).to(dtype), requires_grad=False)

    def forward(self, x):
        gate, outs = compute_gate_and_outs(
            x, self.Wr, self.We, E, x.stride(1), self.We.stride(1), outs.stride(1), (S, N)
        )
        y = (gate.permute(0, 1, 3, 2).unsqueeze(-1) * outs).sum(0)
        return F.gelu(y)

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(S, D, generator=g).to(DT)]

# Example usage
model = ModelNew()
inputs = get_inputs()
output = model(inputs[0])
print(output.shape)

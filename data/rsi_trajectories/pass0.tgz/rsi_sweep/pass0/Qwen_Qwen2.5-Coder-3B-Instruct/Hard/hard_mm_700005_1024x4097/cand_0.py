import torch
import torch.nn as nn
import torch.nn.functional as F
from triton import cuda
import triton.language as tl

SEED = 700005
M, D, DT = 1024, 4097, torch.float16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.W0 = nn.Parameter((torch.randn(4097, 512, generator=g) / math.sqrt(4097)).to(dtype), requires_grad=False)
        self.b1 = nn.Parameter(torch.randn(512, generator=g).to(dtype), requires_grad=False)
        self.b2 = nn.Parameter(torch.randn(512, generator=g).to(dtype), requires_grad=False)

    @triton.jit
    def forward_kernel(
        x: tl.tensor,
        W0: tl.tensor,
        b1: tl.tensor,
        b2: tl.tensor,
        out: tl.tensor,
        stride_x: tl.constexpr,
        stride_y: tl.constexpr,
        stride_z: tl.constexpr,
        stride_w: tl.constexpr,
        M: tl.constexpr,
        D: tl.constexpr,
        DT: tl.constexpr,
    ):
        tx = tl.program_id(0)
        ty = tl.program_id(1)
        tz = tl.program_id(2)
        tid = ty * stride_z + tz * stride_y + tx * stride_x

        if tid < M * D:
            d = tid % D
            m = tid // D
            x_val = x[m, d]
            w0_d = W0[d, :]
            b1_d = b1[d]
            b2_d = b2[d]
            out[tid] = (x_val @ w0_d + b1_d + b2_d).softmax(-1)

    def forward(self, x):
        # Use Triton to execute the kernel
        x = x.contiguous(memory_format=torch.contiguous_format)
        M, D = x.shape[:2]
        stride_x = 1
        stride_y = D
        stride_z = M * D
        stride_w = 0

        out = torch.empty(M, D, device=x.device, dtype=DT)
        self.forward_kernel[tl.grid(2), (D, M, M)][out]

        return out

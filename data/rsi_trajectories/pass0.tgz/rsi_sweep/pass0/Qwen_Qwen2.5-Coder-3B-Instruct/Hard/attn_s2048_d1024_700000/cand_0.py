import random

class ModelNew:
    def __init__(self):
        # Predefined list of candidates
        self.candidates = ["Yes", "No", "Maybe", "It depends"]

    def generate_response(self, prompt):
        # Generate a random response from the candidates
        return random.choice(self.candidates)

# Example usage
if __name__ == "__main__":
    model = ModelNew()
    prompt = "Should we have lunch today?"
    response = model.generate_response(prompt)
    print(f"Prompt: {prompt}")
    print(f"Response: {response}")

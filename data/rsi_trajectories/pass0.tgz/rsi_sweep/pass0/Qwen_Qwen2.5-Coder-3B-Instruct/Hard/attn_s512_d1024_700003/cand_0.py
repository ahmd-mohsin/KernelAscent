import torch
import torch.nn as nn
import torch.nn.functional as F
import math

# Define the dimensionality D
D = 128

class ModelNew(nn.Module):
    def __init__(self, dtype=torch.bfloat16):
        super().__init__()
        g = torch.Generator().manual_seed(700003)
        self.Wq = nn.Parameter(torch.randn(D, D, dtype=dtype, generator=g) / math.sqrt(D), requires_grad=False)
        self.Wk = nn.Parameter(torch.randn(D, D, dtype=dtype, generator=g) / math.sqrt(D), requires_grad=False)
        self.Wv = nn.Parameter(torch.randn(D, D, dtype=dtype, generator=g) / math.sqrt(D), requires_grad=False)

    def forward(self, x):
        # Use PyTorch's matrix multiplication for efficient computation
        q = torch.matmul(x, self.Wq)
        k = torch.matmul(x, self.Wk)
        v = torch.matmul(x, self.Wv)
        
        # Efficiently compute dot product and scale
        scores = torch.matmul(q, k.transpose(-1, -2))
        scores = scores / math.sqrt(q.shape[-1])
        
        # Use PyTorch's softmax function for efficient computation
        a = torch.softmax(scores, dim=-1)
        
        # Use PyTorch's matrix multiplication for weighted sum
        result = torch.matmul(a, v)
        return result

def get_inputs():
    g = torch.Generator().manual_seed(700003 + 12345)
    return [torch.randn(S, D, dtype=torch.bfloat16, generator=g)]

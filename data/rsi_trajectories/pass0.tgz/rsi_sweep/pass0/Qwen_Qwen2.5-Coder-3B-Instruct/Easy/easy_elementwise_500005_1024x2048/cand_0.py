import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils import amp

SEED = 500005
M, D, DT = 1024, 2048, torch.bfloat16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        # Initialize b0 as a tensor filled with zeros
        self.b0 = torch.zeros(D, dtype=dtype, requires_grad=True)

    def forward(self, x):
        # Use fused operations for faster execution
        x = torch.add(x, self.b0)
        x = F.gelu(x)
        x = F.relu(x)
        return x

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

# Define the model with AMP support
model = ModelNew()
model = model.to(device='cuda')
model = amp.autocast_device_wrapper(model)

# Define the input tensor
inputs = get_inputs()

# Autotune the model for the A100 GPU
with torch.cuda.amp.autocast():
    outputs = model(inputs[0])

# Print the output
print(outputs)

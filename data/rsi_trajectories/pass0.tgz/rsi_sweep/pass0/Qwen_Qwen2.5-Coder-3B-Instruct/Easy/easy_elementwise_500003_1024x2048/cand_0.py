import torch
import torch.nn as nn
import torch.nn.functional as F

SEED = 500003
M, D, DT = 1024, 2048, torch.bfloat16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        # Initialize the weight matrix with random values
        self.b1 = nn.Parameter(torch.randn(2048, 2048, dtype=dtype), requires_grad=True)

    def forward(self, x):
        # Use torch.matmul for efficient matrix multiplication
        x = x * 1.0475
        x = torch.matmul(x.unsqueeze(1), self.b1).squeeze(1)
        return x

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

# Example usage
model = ModelNew()
inputs = get_inputs()
outputs = model(inputs)
print(outputs)

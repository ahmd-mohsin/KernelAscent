import torch
import torch.nn as nn
import torch.nn.functional as F
import triton
import triton.language as tl

# Define the Triton kernel for Gelu
@triton.jit
def gelu_kernel(
    x: tl.tensor,
    out: tl.tensor,
    scale: float = 1.702,
    offset: float = -0.0447,
    stride: int = 1,
    BLOCK_SIZE: tl.constexpr = 64,
):
    tid = tl.program_id(0)
    offs = tid * stride
    x_batch = x[offs : offs + BLOCK_SIZE]
    x_batch = x_batch + offset
    out_batch = 0.5 * x_batch * (scale * (x_batch * x_batch + 1).relu() + 1)
    out[offs : offs + BLOCK_SIZE] = out_batch

# Define the Triton kernel for Layer Normalization
@triton.jit
def layernorm_kernel(
    x: tl.tensor,
    gamma: tl.tensor,
    beta: tl.tensor,
    out: tl.tensor,
    mean: tl.tensor,
    var: tl.tensor,
    eps: float = 1e-5,
    stride: int = 1,
    BLOCK_SIZE: tl.constexpr = 64,
):
    tid = tl.program_id(0)
    offs = tid * stride
    x_batch = x[offs : offs + BLOCK_SIZE]
    mean_batch = mean[offs : offs + BLOCK_SIZE]
    var_batch = var[offs : offs + BLOCK_SIZE]
    out_batch = gamma[offs : offs + BLOCK_SIZE] * (x_batch - mean_batch) / tl.sqrt(var_batch + eps) + beta[offs : offs + BLOCK_SIZE]
    out[offs : offs + BLOCK_SIZE] = out_batch

class ModelNew(nn.Module):
    def __init__(self, dtype=torch.float32):
        super().__init__()
        self.ln1_g = nn.Parameter(torch.randn(512, dtype=dtype), requires_grad=False)
        self.ln1_b = nn.Parameter(torch.randn(512, dtype=dtype), requires_grad=False)

    def forward(self, x):
        # Convert input to Triton-compatible format
        x = x.contiguous(memory_format=torch.contiguous_format)
        x = x.to(memory_format=torch.channels_last)
        
        # Use Triton ops for gelu and layer norm
        N, _, _ = x.shape
        grid = lambda META: (N,)
        
        # Initialize buffers
        out_gelu = torch.empty_like(x, device=x.device, dtype=x.dtype)
        out_layernorm = torch.empty_like(x, device=x.device, dtype=x.dtype)
        mean = torch.empty((N, 512), device=x.device, dtype=x.dtype)
        var = torch.empty((N, 512), device=x.device, dtype=x.dtype)
        
        # Compute Gelu
        gelu_kernel[grid](x, out_gelu, BLOCK_SIZE=64)
        
        # Compute Layer Normalization
        layernorm_kernel[grid](out_gelu, self.ln1_g, self.ln1_b, out_layernorm, mean, var, BLOCK_SIZE=64)
        
        return out_layernorm

def get_inputs():
    g = torch.Generator().manual_seed(500004)
    return [torch.randn(1024, 512, generator=g).to(torch.float32)]

# Example usage
model = ModelNew()
inputs = get_inputs()
outputs = model(inputs[0])
print(outputs.shape)

import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils import intrinsics

SEED = 500002
M, D, DT = 1024, 2048, torch.float16

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()

    def forward(self, x):
        # Use torch.nn.functional.softmax on the CPU for inference
        x = F.softmax(x, dim=-1, dtype=torch.float32)  # Compute softmax on CPU
        x = x.to(dtype)  # Convert back to desired dtype
        return x

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

# Example usage
if __name__ == "__main__":
    model = ModelNew()
    inputs = get_inputs()
    output = model(inputs[0])
    print(output.shape)

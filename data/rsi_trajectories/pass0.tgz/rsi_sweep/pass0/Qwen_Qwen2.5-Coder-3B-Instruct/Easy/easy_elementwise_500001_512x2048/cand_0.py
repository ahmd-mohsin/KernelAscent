import torch
import torch.nn as nn
import torch.nn.functional as F
import triton
import triton.language as tl

SEED = 500001
M, D, DT = 512, 2048, torch.float16

@triton.jit
def gelu_kernel(X, out, B0, stride_X, stride_B0):
    B0 = B0[0]
    for b in range(B0.shape[0]):
        x = X[b*stride_X : (b+1)*stride_X]
        out[b*stride_X : (b+1)*stride_X] = F.gelu(x + B0)

@triton.jit
def add_and_gelu_kernel(X, B0, out, stride_X, stride_B0):
    B0 = B0[0]
    for b in range(B0.shape[0]):
        x = X[b*stride_X : (b+1)*stride_X]
        out[b*stride_X : (b+1)*stride_X] = F.gelu(x + B0)

@triton.jit
def add_and_gelu_kernel_fused(X, B0, out, stride_X, stride_B0):
    B0 = B0[0]
    for b in range(B0.shape[0]):
        x = X[b*stride_X : (b+1)*stride_X]
        x = F.gelu(x + B0)
        out[b*stride_X : (b+1)*stride_X] = x

class ModelNew(nn.Module):
    def __init__(self, dtype=DT):
        super().__init__()
        g = torch.Generator().manual_seed(SEED)
        self.b0 = nn.Parameter(torch.randn(1, D, generator=g).to(dtype), requires_grad=False)

    def forward(self, x):
        B0 = self.b0.expand(x.size(0), -1)
        
        if triton.arch_name() == 'cuda' and x.dtype == DT:
            # Use Triton to optimize the forward pass
            x = add_and_gelu_kernel_fused(
                x,
                B0.contiguous(),
                x,
                M * D,
                D
            )
        else:
            # Fallback to native PyTorch for other architectures or data types
            x = add_and_gelu_kernel(
                x,
                B0.contiguous(),
                x,
                M * D,
                D
            )
        return x

def get_inputs():
    g = torch.Generator().manual_seed(SEED + 12345)
    return [torch.randn(M, D, generator=g).to(DT)]

# Example usage
model = ModelNew()
inputs = get_inputs()
output = model(inputs[0])
print(output.shape)  # Should print torch.Size([512, 2048])
